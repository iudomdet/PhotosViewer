"""Full-screen viewer (zoom/pan/100%), video player, filmstrip and side-by-side compare."""
from __future__ import annotations

import os

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QListView, QPushButton, QSlider,
                             QStackedWidget, QVBoxLayout, QWidget)

from .models import PhotoDelegate
from .util import human_size

try:
    from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PyQt6.QtMultimediaWidgets import QVideoWidget
    HAS_MM = True
except Exception:  # pragma: no cover
    HAS_MM = False


class ImageCanvas(QWidget):
    viewChanged = pyqtSignal(float, float, float)   # relative zoom, centre x/y (0..1 of image)
    clicked = pyqtSignal()
    doubleClicked = pyqtSignal()

    def __init__(self, loader, thumbs, tag="main", parent=None):
        super().__init__(parent)
        self.loader, self.thumbs, self.tag = loader, thumbs, tag
        self.iid = None
        self.path = ""
        self.ow = self.oh = 0
        self.fit_img = self.full_img = None
        self.scale = 1.0
        self.off = QPointF(0, 0)
        self.fit_mode = True
        self.hud: list[str] = []
        self.rating = 0
        self.flag = 0
        self.show_hud = True
        self.active = False
        self.sync_enabled = False
        self.dblclick_zoom = True      # False in the single-image viewer: double-click goes back instead
        self._drag = None
        self._moved = False
        self._full_requested = False
        self.setMouseTracking(True)
        self.setMinimumSize(80, 80)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        loader.loaded.connect(self._on_loaded)

    # ---- content
    def show_item(self, iid, path, w=0, h=0):
        self.iid, self.path = iid, path
        self.ow, self.oh = w or 0, h or 0
        self.fit_img = self.full_img = None
        self.fit_mode = True
        self._full_requested = False
        hit = self.loader.cached(iid, False)
        if hit:
            self.ow, self.oh, self.fit_img = hit
        fh = self.loader.cached(iid, True)
        if fh:
            self.ow, self.oh, self.full_img = fh
        if not hit and not fh:
            self.loader.request(self.tag, iid, path, False, urgent=True)
        self._relayout()
        self.update()

    def clear(self):
        self.iid = None
        self.fit_img = self.full_img = None
        self.update()

    def _on_loaded(self, tag, iid, full, ow, oh, img):
        if iid != self.iid or img.isNull():
            return
        self.ow, self.oh = ow, oh
        if full:
            self.full_img = img
        else:
            self.fit_img = img
        if self.fit_mode:
            self._relayout()
        self.update()
        self._maybe_full()

    # ---- geometry
    def fit_scale(self) -> float:
        if not self.ow or not self.oh:
            return 1.0
        return min(self.width() / self.ow, self.height() / self.oh)

    def _relayout(self):
        if self.fit_mode:
            self.scale = self.fit_scale()
            self.off = QPointF((self.width() - self.ow * self.scale) / 2, (self.height() - self.oh * self.scale) / 2)
        else:
            self._clamp()

    def _clamp(self):
        w, h = self.ow * self.scale, self.oh * self.scale
        x = (self.width() - w) / 2 if w <= self.width() else min(0, max(self.width() - w, self.off.x()))
        y = (self.height() - h) / 2 if h <= self.height() else min(0, max(self.height() - h, self.off.y()))
        self.off = QPointF(x, y)

    def resizeEvent(self, e):
        self._relayout()
        super().resizeEvent(e)

    def centre_norm(self):
        if not self.ow:
            return 0.5, 0.5
        cx = (self.width() / 2 - self.off.x()) / (self.ow * self.scale)
        cy = (self.height() / 2 - self.off.y()) / (self.oh * self.scale)
        return cx, cy

    def zoom_at(self, factor: float, anchor: QPointF | None = None, absolute: float | None = None, emit=True):
        if not self.ow:
            return
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        fit = self.fit_scale()
        if absolute is not None:
            new = min(absolute, 24.0)
            to_fit = abs(new - fit) < 0.001
        else:
            new = max(fit, min(self.scale * factor, 24.0))
            to_fit = new <= fit * 1.001
        if to_fit:
            self.fit_mode = True
        else:
            ratio = new / self.scale
            self.off = anchor - (anchor - self.off) * ratio
            self.scale = new
            self.fit_mode = False
        self._relayout()
        self.update()
        self._maybe_full()
        if emit:
            self._emit_view()

    def toggle_100(self, anchor: QPointF | None = None):
        if not self.ow:
            return
        if not self.fit_mode and abs(self.scale - 1.0) < 0.01:
            self.fit_mode = True
            self._relayout()
            self.update()
            self._emit_view()
        else:
            self.zoom_at(1, anchor, absolute=1.0)

    def fit(self):
        self.fit_mode = True
        self._relayout()
        self.update()
        self._emit_view()

    def _emit_view(self):
        if self.sync_enabled and self.ow:
            cx, cy = self.centre_norm()
            self.viewChanged.emit(self.scale / max(self.fit_scale(), 1e-6), cx, cy)

    def apply_view(self, rel: float, cx: float, cy: float):
        if not self.ow:
            return
        if rel <= 1.001:
            self.fit()
            return
        self.fit_mode = False
        self.scale = self.fit_scale() * rel
        self.off = QPointF(self.width() / 2 - cx * self.ow * self.scale, self.height() / 2 - cy * self.oh * self.scale)
        self._clamp()
        self.update()
        self._maybe_full()

    def _maybe_full(self):
        if (self.fit_mode or self.full_img is not None or self._full_requested or self.fit_img is None
                or self.iid is None or not self.ow):
            return
        if self.scale > (self.fit_img.width() / self.ow) * 1.02:
            self._full_requested = True
            self.loader.request(self.tag, self.iid, self.path, True, urgent=True)

    # ---- painting
    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#0b0b0d"))
        img = self.full_img or self.fit_img
        if img is not None and self.ow:
            dest = QRectF(self.off.x(), self.off.y(), self.ow * self.scale, self.oh * self.scale)
            vis = dest.intersected(QRectF(self.rect()))
            if vis.width() > 0 and vis.height() > 0:
                sx = img.width() / dest.width()
                sy = img.height() / dest.height()
                src = QRectF((vis.x() - dest.x()) * sx, (vis.y() - dest.y()) * sy, vis.width() * sx, vis.height() * sy)
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, self.scale < 1.0 or img is self.fit_img and self.scale < 2)
                p.drawImage(vis, img, src)
        elif self.iid is not None:
            pm = self.thumbs.get(self.iid)
            if pm is not None:
                s = pm.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
                p.setOpacity(0.7)
                p.drawPixmap((self.width() - s.width()) // 2, (self.height() - s.height()) // 2,
                             s.width(), s.height(), pm)
                p.setOpacity(1)
        if self.iid is not None and self.show_hud:
            self._paint_hud(p)
        if self.active:
            p.setPen(QPen(QColor("#4dabf7"), 3))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(self.rect().adjusted(1, 1, -2, -2))
        p.end()

    def _paint_hud(self, p: QPainter):
        f = QFont(self.font())
        f.setPointSizeF(max(9.0, f.pointSizeF()))
        p.setFont(f)
        fm = p.fontMetrics()
        if self.hud:
            wmax = max(fm.horizontalAdvance(t) for t in self.hud) + 16
            box = QRectF(8, 8, min(wmax, self.width() - 16), fm.height() * len(self.hud) + 10)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            p.drawRoundedRect(box, 6, 6)
            p.setPen(QColor("#f1f3f5"))
            for i, t in enumerate(self.hud):
                p.drawText(QRectF(16, 13 + i * fm.height(), box.width() - 16, fm.height()),
                           Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                           fm.elidedText(t, Qt.TextElideMode.ElideMiddle, int(box.width() - 16)))
        parts = []
        if self.flag > 0:
            parts.append(("✓ PICK", "#30a46c"))
        elif self.flag < 0:
            parts.append(("✕ REJECT", "#e5484d"))
        if self.rating:
            parts.append(("★" * self.rating, "#ffc53d"))
        x = self.width() - 10
        f.setPointSizeF(f.pointSizeF() + 3)
        f.setBold(True)
        p.setFont(f)
        fm = p.fontMetrics()
        for text, col in parts:
            w = fm.horizontalAdvance(text) + 18
            box = QRectF(x - w, 8, w, fm.height() + 8)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 170))
            p.drawRoundedRect(box, 8, 8)
            p.setPen(QColor(col))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, text)
            x -= w + 6

    # ---- mouse
    def wheelEvent(self, e):
        dy = e.angleDelta().y()
        if dy:
            self.zoom_at(1.25 if dy > 0 else 0.8, e.position())
        e.accept()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.position()
            self._moved = False
        self.clicked.emit()

    def mouseMoveEvent(self, e):
        if self._drag is not None and not self.fit_mode:
            d = e.position() - self._drag
            if d.manhattanLength() > 2:
                self._moved = True
            self.off += d
            self._drag = e.position()
            self._clamp()
            self.update()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            self._emit_view()

    def mouseReleaseEvent(self, e):
        self._drag = None
        self.unsetCursor()

    def mouseDoubleClickEvent(self, e):
        if self.dblclick_zoom:
            self.toggle_100(e.position())
        else:
            self.doubleClicked.emit()


class VideoPane(QWidget):
    """QtMultimedia player, created lazily on first video so photo-only sessions never touch audio/video devices."""
    openExternal = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.path = ""
        self.ok = HAS_MM and not os.environ.get("PV6_NO_MM")
        self._ready = False
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(0)
        self.msg = QLabel("")
        self.msg.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ext = QPushButton("เปิดด้วยโปรแกรมเริ่มต้น")
        self.ext.clicked.connect(lambda: self.openExternal.emit(self.path))
        self.lay.addWidget(self.msg, 1)
        self.lay.addWidget(self.ext)

    def _init_mm(self):
        self._ready = True
        self.video = QVideoWidget()
        self.audio = QAudioOutput()
        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video)
        self.msg.hide()
        self.lay.removeWidget(self.ext)
        self.lay.insertWidget(0, self.video, 1)
        bar = QHBoxLayout()
        bar.setContentsMargins(8, 4, 8, 4)
        self.btn = QPushButton("▶")
        self.btn.setFixedWidth(40)
        self.btn.clicked.connect(self.toggle)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderMoved.connect(self.player.setPosition)
        self.lbl = QLabel("0:00 / 0:00")
        for w in (self.btn, self.slider, self.lbl, self.ext):
            bar.addWidget(w)
        self.lay.addLayout(bar)
        self.player.positionChanged.connect(self._pos)
        self.player.durationChanged.connect(lambda d: self.slider.setRange(0, d))
        self.player.playbackStateChanged.connect(
            lambda s: self.btn.setText("❚❚" if s == QMediaPlayer.PlaybackState.PlayingState else "▶"))
        self.player.errorOccurred.connect(lambda *a: self.lbl.setText("เล่นไม่ได้ – ลองปุ่มเปิดด้วยโปรแกรมเริ่มต้น"))

    @staticmethod
    def _fmt(ms):
        s = int(ms / 1000)
        return f"{s // 60}:{s % 60:02d}"

    def _pos(self, ms):
        if not self.slider.isSliderDown():
            self.slider.setValue(ms)
        self.lbl.setText(f"{self._fmt(ms)} / {self._fmt(self.player.duration())}")

    def load(self, path):
        self.path = path
        if not self.ok:
            self.msg.setText("เล่นวิดีโอในโปรแกรมไม่ได้ในเครื่องนี้ – กดปุ่มด้านล่างเพื่อเปิดด้วยโปรแกรมเริ่มต้น\n" + os.path.basename(path))
            return
        if not self._ready:
            self._init_mm()
        self.player.stop()
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def toggle(self):
        if not (self.ok and self._ready):
            return
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def stop(self):
        if self.ok and self._ready:
            self.player.stop()
            self.player.setSource(QUrl())


def make_filmstrip(model, delegate) -> QListView:
    v = QListView()
    v.setModel(model)
    v.setItemDelegate(delegate)
    v.setFlow(QListView.Flow.LeftToRight)
    v.setWrapping(False)
    v.setUniformItemSizes(True)
    v.setSelectionMode(QListView.SelectionMode.SingleSelection)
    v.setHorizontalScrollMode(QListView.ScrollMode.ScrollPerPixel)
    v.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    v.setFixedHeight(delegate.cell + 22)
    v.setFrameShape(QFrame.Shape.NoFrame)
    return v


class ViewerPage(QWidget):
    navigate = pyqtSignal(int)        # row clicked on filmstrip
    rowShown = pyqtSignal(int)
    closeRequested = pyqtSignal()
    openExternal = pyqtSignal(str)

    def __init__(self, model, loader, thumbs, parent=None):
        super().__init__(parent)
        self.model, self.loader, self.thumbs = model, loader, thumbs
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.stack = QStackedWidget()
        self.canvas = ImageCanvas(loader, thumbs, "main")
        self.canvas.dblclick_zoom = False
        self.canvas.doubleClicked.connect(self.closeRequested)
        self.video = VideoPane()
        self.video.openExternal.connect(self.openExternal)
        self.stack.addWidget(self.canvas)
        self.stack.addWidget(self.video)
        lay.addWidget(self.stack, 1)
        self.delegate = PhotoDelegate(thumbs, compact=True)
        self.delegate.cell = 74
        self.strip = make_filmstrip(model, self.delegate)
        self.strip.clicked.connect(lambda i: self.navigate.emit(i.row()))
        lay.addWidget(self.strip)
        self.row = -1
        self._lock = False
        self.strip_timer = QTimer(self)
        self.strip_timer.setSingleShot(True)
        self.strip_timer.timeout.connect(self._strip_request)
        self.strip.horizontalScrollBar().valueChanged.connect(lambda *_: self.strip_timer.start(40))
        self.info_provider = None     # callable(id) -> dict for HUD

    def set_dark(self, dark):
        self.delegate.dark = dark

    def show_row(self, row: int, prefetch=True):
        rd = self.model.row_data(row)
        if rd is None:
            return
        self.row = row
        iid, path, kind = rd[0], rd[1], rd[2]
        info = self.info_provider(iid) if self.info_provider else {}
        if kind == 1:
            self.canvas.clear()
            self.stack.setCurrentWidget(self.video)
            self.video.load(path)
        else:
            self.video.stop()
            self.stack.setCurrentWidget(self.canvas)
            self.canvas.show_item(iid, path, (info or {}).get("w") or 0, (info or {}).get("h") or 0)
        self.refresh_hud()
        self._lock = True
        self.strip.setCurrentIndex(self.model.index(row))
        self.strip.scrollTo(self.model.index(row), QListView.ScrollHint.PositionAtCenter)
        self._lock = False
        self._strip_request()
        self.rowShown.emit(row)
        if prefetch:
            self.loader.drop_prefetch()
            for d in (1, -1, 2, -2, 3):
                r = self.model.row_data(row + d)
                if r and r[2] == 0:
                    self.loader.request("prefetch", r[0], r[1], False, urgent=False)

    def refresh_hud(self):
        rd = self.model.row_data(self.row)
        if rd is None:
            return
        iid, path = rd[0], rd[1]
        info = (self.info_provider(iid) if self.info_provider else None) or {}
        lines = [f"{os.path.basename(path)}   ({self.row + 1}/{self.model.rowCount()})"]
        bits = []
        if info.get("w"):
            bits.append(f"{info['w']}×{info['h']}")
        if info.get("size"):
            bits.append(human_size(info["size"]))
        if info.get("taken"):
            bits.append(info["taken"])
        if info.get("camera"):
            bits.append(info["camera"])
        if bits:
            lines.append("  ·  ".join(bits))
        self.canvas.hud = lines
        self.canvas.rating, self.canvas.flag = rd[3], rd[4]
        self.canvas.update()

    def _strip_request(self):
        v = self.strip
        first = v.indexAt(v.viewport().rect().topLeft())
        last = v.indexAt(v.viewport().rect().topRight())
        a = first.row() if first.isValid() else max(0, self.row - 8)
        b = last.row() if last.isValid() else min(self.model.rowCount() - 1, self.row + 8)
        items = [(r[0], r[1], r[2]) for i in range(max(0, a - 3), b + 6) if (r := self.model.row_data(i))]
        self.thumbs.want(items)

    def stop(self):
        self.video.stop()


class ComparePane(QFrame):
    activated = pyqtSignal(object)

    def __init__(self, loader, thumbs, tag, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(2)
        self.canvas = ImageCanvas(loader, thumbs, tag)
        self.canvas.clicked.connect(lambda: self.activated.emit(self))
        lay.addWidget(self.canvas, 1)
        self.row_id = None


class ComparePage(QWidget):
    changed = pyqtSignal()

    def __init__(self, loader, thumbs, parent=None):
        super().__init__(parent)
        self.loader, self.thumbs = loader, thumbs
        self.lay = QHBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(3)
        self.panes: list[ComparePane] = []
        self.active: ComparePane | None = None
        self.sync = True
        self._busy = False

    def set_items(self, items):
        """items: [(id, path, w, h, rating, flag, info_lines)]"""
        for p in self.panes:
            p.setParent(None)
            p.deleteLater()
        self.panes = []
        for n, it in enumerate(items):
            pane = ComparePane(self.loader, self.thumbs, f"cmp{n}")
            pane.row_id = it["id"]
            pane.activated.connect(self.set_active)
            pane.canvas.sync_enabled = True
            pane.canvas.viewChanged.connect(lambda rel, cx, cy, src=pane: self._sync(src, rel, cx, cy))
            self.lay.addWidget(pane)
            self.panes.append(pane)
            self.update_item(n, it)
            pane.canvas.show_item(it["id"], it["path"], it.get("w") or 0, it.get("h") or 0)
        self.set_active(self.panes[0] if self.panes else None)

    def update_item(self, n, it):
        c = self.panes[n].canvas
        c.hud = it.get("lines", [])
        c.rating, c.flag = it.get("rating", 0), it.get("flag", 0)
        c.update()

    def _sync(self, src, rel, cx, cy):
        if not self.sync or self._busy:
            return
        self._busy = True
        for p in self.panes:
            if p is not src:
                p.canvas.apply_view(rel, cx, cy)
        self._busy = False

    def set_active(self, pane):
        self.active = pane
        for p in self.panes:
            p.canvas.active = p is pane and len(self.panes) > 1
            p.canvas.update()
        self.changed.emit()

    def move_active(self, d):
        if self.panes and self.active in self.panes:
            self.set_active(self.panes[(self.panes.index(self.active) + d) % len(self.panes)])

    def pane_for(self, iid):
        for n, p in enumerate(self.panes):
            if p.row_id == iid:
                return n
        return -1

    def remove_id(self, iid) -> bool:
        n = self.pane_for(iid)
        if n < 0:
            return False
        p = self.panes.pop(n)
        p.setParent(None)
        p.deleteLater()
        self.set_active(self.panes[min(n, len(self.panes) - 1)] if self.panes else None)
        return True
