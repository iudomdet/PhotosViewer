"""Windows Explorer 'Tags' (System.Keywords) through pywin32. Everything degrades to DB-only elsewhere."""
from __future__ import annotations

import os

from .util import split_tags

TAGGABLE = {".jpg", ".jpeg", ".tif", ".tiff"}


def available() -> bool:
    if os.name != "nt":
        return False
    try:
        import pythoncom  # noqa: F401
        from win32com.propsys import propsys  # noqa: F401
        return True
    except Exception:
        return False


class TagSession:
    """COM must be initialised per thread: use as a context manager inside the worker thread."""

    def __init__(self):
        self.ok = False

    def __enter__(self):
        if os.name == "nt":
            try:
                import pythoncom
                from win32com.propsys import propsys
                from win32com.shell import shellcon
                pythoncom.CoInitialize()
                self._pc, self._ps, self._sc = pythoncom, propsys, shellcon
                self.ok = True
            except Exception:
                self.ok = False
        return self

    def __exit__(self, *exc):
        if self.ok:
            self._pc.CoUninitialize()

    def read(self, path: str) -> list[str]:
        key = self._ps.PSGetPropertyKeyFromName("System.Keywords")
        store = self._ps.SHGetPropertyStoreFromParsingName(
            os.path.abspath(path), None, self._sc.GPS_DEFAULT, self._ps.IID_IPropertyStore)
        value = store.GetValue(key).GetValue()
        if value is None:
            return []
        return split_tags([value] if isinstance(value, str) else list(value))

    def write(self, path: str, tags: list[str]):
        key = self._ps.PSGetPropertyKeyFromName("System.Keywords")
        store = self._ps.SHGetPropertyStoreFromParsingName(
            os.path.abspath(path), None, self._sc.GPS_READWRITE, self._ps.IID_IPropertyStore)
        store.SetValue(key, self._ps.PROPVARIANTType(list(tags), self._pc.VT_VECTOR | self._pc.VT_BSTR))
        store.Commit()
