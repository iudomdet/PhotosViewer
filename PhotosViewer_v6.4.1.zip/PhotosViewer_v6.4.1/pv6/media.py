"""Thumbnails, metadata and video helpers (no Qt here: safe to use from any thread)."""
from __future__ import annotations

import hashlib
import html
import io
import os
import re
import subprocess
from datetime import datetime

from PIL import Image, ImageOps

from .util import no_window_flags

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
    HEIC_OK = True
except Exception:
    HEIC_OK = False

Image.MAX_IMAGE_PIXELS = None
THUMB_EDGE = 360


def ffmpeg_exe() -> str | None:
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        from shutil import which
        return which("ffmpeg")


def thumb_key(path: str, size: int, mtime_ns: int = 0) -> str:
    return hashlib.sha1(f"{path}|{size}|{mtime_ns}".encode("utf-8", "surrogatepass")).hexdigest()


def thumb_file(cache_dir: str, key: str) -> str:
    return os.path.join(cache_dir, key[:2], key + ".jpg")


def open_image(path: str, draft: tuple[int, int] | None = None) -> Image.Image:
    im = Image.open(path)
    if draft and im.format == "JPEG":
        im.draft("RGB", draft)
    im.load()
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "L"):
        im = im.convert("RGBA").convert("RGB") if "A" in im.mode or im.mode == "P" else im.convert("RGB")
    return im


def _video_frame(path: str, edge: int) -> Image.Image | None:
    exe = ffmpeg_exe()
    if not exe:
        return None
    for seek in ("1", "0"):
        try:
            p = subprocess.run(
                [exe, "-v", "error", "-ss", seek, "-i", path, "-frames:v", "1",
                 "-vf", f"scale='min({edge},iw)':-2", "-f", "image2pipe", "-vcodec", "mjpeg", "-"],
                capture_output=True, timeout=30, creationflags=no_window_flags())
            if p.stdout:
                return Image.open(io.BytesIO(p.stdout)).convert("RGB")
        except Exception:
            pass
    return None


def make_thumb(path: str, kind: int, edge: int = THUMB_EDGE) -> bytes | None:
    """JPEG bytes of a thumbnail whose longest side is *edge*."""
    try:
        if kind == 1:
            im = _video_frame(path, edge)
            if im is None:
                return None
        else:
            im = open_image(path, (edge * 2, edge * 2))
        im.thumbnail((edge, edge), Image.LANCZOS)
        buf = io.BytesIO()
        im.convert("RGB").save(buf, "JPEG", quality=85)
        return buf.getvalue()
    except Exception:
        return None


def ensure_thumb(cache_dir: str, path: str, kind: int, mtime_ns: int) -> str | None:
    key = thumb_key(path, THUMB_EDGE, mtime_ns)
    target = thumb_file(cache_dir, key)
    if os.path.exists(target):
        return target
    data = make_thumb(path, kind)
    if not data:
        return None
    os.makedirs(os.path.dirname(target), exist_ok=True)
    tmp = target + f".{os.getpid()}.tmp"
    with open(tmp, "wb") as fh:
        fh.write(data)
    os.replace(tmp, target)
    return target


# ---------------------------------------------------------------- metadata
def _dms(val, ref):
    try:
        d = float(val[0]) + float(val[1]) / 60 + float(val[2]) / 3600
        return -d if ref in ("S", "W") else d
    except Exception:
        return None


def _parse_dt(s) -> str | None:
    if not s:
        return None
    s = str(s).strip().replace("\x00", "")
    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y:%m:%d"):
        try:
            d = datetime.strptime(s[:19], fmt)
            if d.year > 1970:
                return d.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    return None


def dhash_of(im: Image.Image) -> int:
    g = im.convert("L").resize((9, 8), Image.LANCZOS)
    px = list(g.getdata())
    v = 0
    for r in range(8):
        for c in range(8):
            v = (v << 1) | (1 if px[r * 9 + c] > px[r * 9 + c + 1] else 0)
    return v - (1 << 64) if v >= (1 << 63) else v     # signed for sqlite


def photo_meta(path: str, want_hash=True) -> dict:
    out: dict = {}
    try:
        with Image.open(path) as im:
            out["w"], out["h"] = im.size
            ex = im.getexif()
            if ex:
                sub = ex.get_ifd(0x8769) if hasattr(ex, "get_ifd") else {}
                out["taken"] = _parse_dt(sub.get(36867) or sub.get(36868) or ex.get(36867) or ex.get(306))
                cam = " ".join(x for x in (str(ex.get(271, "")).strip(), str(ex.get(272, "")).strip()) if x)
                out["camera"] = cam.replace("\x00", "")
                try:
                    gps = ex.get_ifd(0x8825)
                    if gps and 2 in gps and 4 in gps:
                        out["lat"] = _dms(gps[2], gps.get(1))
                        out["lon"] = _dms(gps[4], gps.get(3))
                except Exception:
                    pass
                orient = ex.get(274)
                if orient in (5, 6, 7, 8) and "w" in out:
                    out["w"], out["h"] = out["h"], out["w"]
            if want_hash:
                if im.format == "JPEG":
                    im.draft("L", (64, 64))
                out["dhash"] = dhash_of(ImageOps.exif_transpose(im))
    except Exception:
        pass
    return out


_DUR = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)")
_SIZE = re.compile(r"Video:.*?,\s*(\d{2,5})x(\d{2,5})")
_CT = re.compile(r"creation_time\s*:\s*(\S+)")
_ROT = re.compile(r"rotate\s*:\s*(-?\d+)")


def video_meta(path: str) -> dict:
    out: dict = {}
    exe = ffmpeg_exe()
    if not exe:
        return out
    try:
        p = subprocess.run([exe, "-hide_banner", "-i", path], capture_output=True, timeout=30,
                           creationflags=no_window_flags())
        txt = p.stderr.decode("utf-8", "replace")
        m = _DUR.search(txt)
        if m:
            out["duration"] = int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3])
        m = _SIZE.search(txt)
        if m:
            out["w"], out["h"] = int(m[1]), int(m[2])
            r = _ROT.search(txt)
            if r and abs(int(r[1])) in (90, 270):
                out["w"], out["h"] = out["h"], out["w"]
        m = _CT.search(txt)
        if m:
            out["taken"] = _parse_dt(m[1].replace("T", " ").split(".")[0].rstrip("Z"))
            if out["taken"]:      # container times are UTC; show local time
                try:
                    d = datetime.strptime(out["taken"], "%Y-%m-%d %H:%M:%S")
                    import calendar
                    ts = calendar.timegm(d.timetuple())
                    out["taken"] = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass
    except Exception:
        pass
    return out


def read_meta(path: str, kind: int, want_hash=True) -> dict:
    return video_meta(path) if kind == 1 else photo_meta(path, want_hash)


def hamming(a: int, b: int) -> int:
    return bin((a ^ b) & 0xFFFFFFFFFFFFFFFF).count("1")


def sharpness(path: str) -> float:
    """Variance of a simple Laplacian on a small greyscale copy – higher = sharper (for keep-best)."""
    try:
        im = open_image(path, (512, 512)).convert("L")
        im.thumbnail((512, 512))
        w, h = im.size
        px = im.load()
        s = s2 = n = 0
        for y in range(1, h - 1, 2):
            for x in range(1, w - 1, 2):
                v = 4 * px[x, y] - px[x - 1, y] - px[x + 1, y] - px[x, y - 1] - px[x, y + 1]
                s += v
                s2 += v * v
                n += 1
        return (s2 / n - (s / n) ** 2) if n else 0.0
    except Exception:
        return 0.0


def write_xmp_rating(path: str, rating: int, flag: int):
    """Sidecar .xmp readable by Lightroom/Bridge/darktable. flag -1 -> Label 'Rejected'; rating -1 = reject."""
    side = os.path.splitext(path)[0] + ".xmp"
    r = -1 if flag < 0 else rating
    label = "Select" if flag > 0 else ""
    xml = ('<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>\n'
           '<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
           f'<rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmp:Rating="{r}"'
           + (f' xmp:Label="{label}"' if label else "") + '/></rdf:RDF></x:xmpmeta>\n<?xpacket end="w"?>')
    with open(side, "w", encoding="utf-8") as fh:
        fh.write(xml)
    return side


def export_copy(src: str, dst_dir: str, long_edge: int, quality: int, kind: int) -> str:
    """Save a resized JPEG copy (photos only). long_edge 0 = original size. Never overwrites."""
    base = os.path.splitext(os.path.basename(src))[0]
    dst = os.path.join(dst_dir, base + ".jpg")
    n = 1
    while os.path.exists(dst):
        dst = os.path.join(dst_dir, f"{base}_{n}.jpg")
        n += 1
    im = open_image(src)
    if long_edge and max(im.size) > long_edge:
        im.thumbnail((long_edge, long_edge), Image.LANCZOS)
    im.convert("RGB").save(dst, "JPEG", quality=quality, optimize=True)
    return dst


def load_for_view(path: str, edge: int):
    """(orig_w, orig_h, PIL RGB image) – edge=0 keeps full resolution, otherwise the long side is capped."""
    im = Image.open(path)
    ow, oh = im.size
    try:
        orient = im.getexif().get(274)
    except Exception:
        orient = None
    if orient in (5, 6, 7, 8):
        ow, oh = oh, ow
    if edge and im.format == "JPEG":
        im.draft("RGB", (edge, edge))
    im.load()
    im = ImageOps.exif_transpose(im)
    if im.mode != "RGB":
        im = im.convert("RGBA").convert("RGB") if "A" in im.mode or im.mode == "P" else im.convert("RGB")
    if edge and max(im.size) > edge:
        im.thumbnail((edge, edge), Image.LANCZOS)
    return ow, oh, im


_XMP_SUBJ = re.compile(rb"<dc:subject>(.*?)</dc:subject>", re.S)
_LI = re.compile(rb"<rdf:li[^>]*>(.*?)</rdf:li>", re.S)


def embedded_tags(path: str) -> list[str]:
    """Keywords stored inside the file: XMP dc:subject, EXIF XPKeywords, IPTC keywords (all platforms)."""
    out: list[str] = []
    try:
        with open(path, "rb") as fh:
            head = fh.read(2 << 20)
        m = _XMP_SUBJ.search(head)
        if m:
            out += [html.unescape(x.decode("utf-8", "replace")).strip() for x in _LI.findall(m[1])]
    except Exception:
        pass
    try:
        with Image.open(path) as im:
            xp = im.getexif().get(0x9C9E)
            if xp:
                if isinstance(xp, bytes):
                    xp = xp.decode("utf-16le", "ignore")
                out += [t.strip() for t in str(xp).replace("\x00", "").split(";")]
            try:
                from PIL import IptcImagePlugin
                iptc = IptcImagePlugin.getiptcinfo(im) or {}
                kw = iptc.get((2, 25))
                if kw:
                    for k in (kw if isinstance(kw, list) else [kw]):
                        out.append(k.decode("utf-8", "replace") if isinstance(k, bytes) else str(k))
            except Exception:
                pass
    except Exception:
        pass
    return [t for t in out if t]
