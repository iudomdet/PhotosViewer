DARK = """
QWidget { background:#18191c; color:#e6e8ec; font-size:10pt; }
QMainWindow, QDialog { background:#18191c; }
QToolBar { background:#202226; border:0; padding:4px; spacing:6px; }
QToolBar QLabel { background:transparent; }
QLineEdit, QComboBox, QSpinBox, QTextEdit, QPlainTextEdit { background:#2a2c31; border:1px solid #3a3d44; border-radius:5px; padding:4px 6px; }
QComboBox QAbstractItemView { background:#2a2c31; selection-background-color:#3b5bdb; }
QPushButton, QToolButton { background:#2f3238; border:1px solid #3f434b; border-radius:5px; padding:5px 10px; }
QPushButton:hover, QToolButton:hover { background:#3a3e46; }
QPushButton:checked, QToolButton:checked { background:#3b5bdb; border-color:#5c7cfa; }
QListView, QTreeWidget, QListWidget { background:#1d1e22; border:0; }
QTreeWidget::item, QListWidget::item { padding:3px; }
QTreeWidget::item:selected, QListWidget::item:selected { background:#3b5bdb; color:white; }
QTabWidget::pane { border:0; }
QTabBar::tab { background:#202226; padding:6px 6px; border:0; }
QTabBar::tab:selected { background:#3b5bdb; color:white; }
QStatusBar { background:#202226; }
QDockWidget::title { background:#202226; padding:4px; }
QMenuBar, QMenu { background:#202226; }
QMenu::item:selected, QMenuBar::item:selected { background:#3b5bdb; }
QProgressBar { background:#2a2c31; border:0; border-radius:4px; text-align:center; max-height:14px; }
QProgressBar::chunk { background:#4c6ef5; border-radius:4px; }
QScrollBar:vertical { background:#18191c; width:12px; } QScrollBar::handle:vertical { background:#41454d; border-radius:5px; min-height:30px; }
QScrollBar:horizontal { background:#18191c; height:12px; } QScrollBar::handle:horizontal { background:#41454d; border-radius:5px; min-width:30px; }
QScrollBar::add-line, QScrollBar::sub-line { width:0; height:0; }
QLabel#banner { background:#3b2f0b; color:#ffd43b; padding:6px 10px; }
"""
LIGHT = """
QWidget { background:#f4f5f8; color:#1c1d21; font-size:10pt; }
QToolBar { background:#e8eaf0; border:0; padding:4px; spacing:6px; }
QToolBar QLabel { background:transparent; }
QLineEdit, QComboBox, QSpinBox { background:white; border:1px solid #c7cbd6; border-radius:5px; padding:4px 6px; }
QComboBox QAbstractItemView { background:white; selection-background-color:#4c6ef5; }
QPushButton, QToolButton { background:#fff; border:1px solid #c7cbd6; border-radius:5px; padding:5px 10px; }
QPushButton:hover, QToolButton:hover { background:#e9ecf5; }
QPushButton:checked, QToolButton:checked { background:#4c6ef5; color:white; }
QListView, QTreeWidget, QListWidget { background:#fbfbfd; border:0; }
QTreeWidget::item:selected, QListWidget::item:selected { background:#4c6ef5; color:white; }
QTabBar::tab { background:#e8eaf0; padding:6px 6px; }
QTabBar::tab:selected { background:#4c6ef5; color:white; }
QStatusBar, QMenuBar, QMenu { background:#e8eaf0; }
QMenu::item:selected, QMenuBar::item:selected { background:#4c6ef5; color:white; }
QProgressBar { background:#dde0ea; border:0; border-radius:4px; text-align:center; max-height:14px; }
QProgressBar::chunk { background:#4c6ef5; border-radius:4px; }
QLabel#banner { background:#fff3bf; color:#5f3b00; padding:6px 10px; }
"""
