"""Optional face grouping (needs face_recognition + dlib + numpy). Everything else works without it."""
from __future__ import annotations

import sys

THRESHOLD = 0.48


def available():
    try:
        import numpy  # noqa: F401
        import face_recognition  # noqa: F401
        return True, ""
    except Exception as exc:
        if getattr(sys, "frozen", False):
            hint = "ไฟล์ EXE นี้ build โดยไม่รวม Face Recognition – ให้ใช้ build_exe_face.bat"
        else:
            hint = "ติดตั้งด้วย: pip install -r requirements-face.txt  (ต้องติดตั้งใน Python ตัวเดียวกับที่รันโปรแกรม)"
        return False, f"โหลด Face Recognition ไม่สำเร็จ: {exc}\n\n{hint}"


def people_list(lib):
    return [(r[0], r[1], r[2]) for r in lib.conn().execute(
        "select p.id, p.name, count(distinct f.image_id) from people p join faces f on f.person_id=p.id "
        "group by p.id order by count(distinct f.image_id) desc")]


def rename(lib, pid, name):
    with lib._write:
        lib.conn().execute("update people set name=? where id=?", (name, pid))
        lib.conn().commit()


def merge(lib, src, dst):
    with lib._write:
        c = lib.conn()
        c.execute("update faces set person_id=? where person_id=?", (dst, src))
        c.execute("delete from people where id=?", (src,))
        c.commit()


def scan(lib, ids, task):
    import numpy as np
    import face_recognition
    from . import media
    c = lib.conn()
    todo = lib.conn().execute("select id, disp from images where kind=0 and id not in (select image_id from face_done)").fetchall()
    if ids is not None:
        keep = set(ids)
        todo = [r for r in todo if r["id"] in keep]
    # centroids of existing people
    sums: dict[int, tuple] = {}
    for r in c.execute("select person_id, enc from faces where person_id is not null"):
        e = np.frombuffer(r["enc"], dtype=np.float64)
        s, n = sums.get(r["person_id"], (np.zeros(128), 0))
        sums[r["person_id"]] = (s + e, n + 1)
    n_faces = 0
    for k, r in enumerate(todo):
        if task.is_cancelled():
            break
        try:
            _, _, im = media.load_for_view(r["disp"], 1100)
            arr = np.asarray(im)
            locs = face_recognition.face_locations(arr, model="hog")
            encs = face_recognition.face_encodings(arr, locs) if locs else []
        except Exception:
            encs = []
        with lib._write:
            for e in encs:
                pid, best = None, THRESHOLD
                for p, (s, n) in sums.items():
                    d = float(np.linalg.norm(s / n - e))
                    if d < best:
                        pid, best = p, d
                if pid is None:
                    pid = c.execute("insert into people(name) values('')").lastrowid
                    sums[pid] = (np.zeros(128), 0)
                s, n = sums[pid]
                sums[pid] = (s + e, n + 1)
                c.execute("insert into faces(image_id, person_id, enc) values(?,?,?)", (r["id"], pid, e.tobytes()))
                n_faces += 1
            c.execute("insert or ignore into face_done values(?)", (r["id"],))
            c.commit()
        task.progress.emit((k + 1, len(todo)))
    return {"scanned": len(todo), "faces": n_faces, "people": len(sums)}


def images_of(lib, pid):
    return [r[0] for r in lib.conn().execute("select distinct image_id from faces where person_id=?", (pid,))]


def tag_named(lib):
    """Add each named person's name as a tag to every image they appear in. Returns (people, image ids touched)."""
    touched, n = set(), 0
    for pid, name, _cnt in people_list(lib):
        if not (name or "").strip():
            continue
        ids = images_of(lib, pid)
        if ids:
            lib.add_tags(ids, [name.strip()])
            touched.update(ids)
            n += 1
    return n, sorted(touched)
