"""SQLite library for Photos Viewer 6. Rows are keyed by integer id so moves/renames keep ratings, tags, albums."""
from __future__ import annotations

import os
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime

from .util import canon, kind_of, scope_range, SKIP_DIRS, split_tags

SCHEMA = """
create table if not exists images(
  id integer primary key,
  path text not null unique,      -- canonical key (case-folded on Windows)
  disp text not null,             -- real-case absolute path
  name text not null,
  dir text not null,              -- canonical key of parent dir
  size integer not null default 0,
  mtime_ns integer not null default 0,
  kind integer not null default 0,   -- 0 photo, 1 video
  w integer, h integer,
  taken text,                     -- 'YYYY-MM-DD HH:MM:SS' (mtime until metadata is read)
  lat real, lon real,
  camera text default '',
  duration real,
  tags text not null default '',
  rating integer not null default 0,
  flag integer not null default 0,   -- 1 pick, -1 reject
  meta_done integer not null default 0,
  dhash integer
);
create index if not exists ix_images_dir on images(dir);
create index if not exists ix_images_taken on images(taken);
create index if not exists ix_images_rating on images(rating);
create index if not exists ix_images_flag on images(flag);
create table if not exists albums(id integer primary key, name text not null unique);
create table if not exists album_images(
  album_id integer not null references albums(id) on delete cascade,
  image_id integer not null references images(id) on delete cascade,
  primary key(album_id, image_id));
create table if not exists faces(
  id integer primary key,
  image_id integer not null references images(id) on delete cascade,
  person_id integer, enc blob not null);
create table if not exists people(id integer primary key, name text not null default '');
create table if not exists face_done(image_id integer primary key references images(id) on delete cascade);
create index if not exists ix_faces_image on faces(image_id);
create index if not exists ix_faces_person on faces(person_id);
"""

SORTS = {
    "taken_new": "taken desc, name collate nocase",
    "taken_old": "taken asc, name collate nocase",
    "name": "name collate nocase asc",
    "name_desc": "name collate nocase desc",
    "mtime": "mtime_ns desc",
    "size": "size desc",
    "rating": "rating desc, taken desc",
}
LIST_COLS = "id, disp, kind, rating, flag"


@dataclass
class Filter:
    folder: str = ""
    recursive: bool = True
    text: str = ""
    min_rating: int = 0
    flag: str = "any"        # any | pick | reject | not_reject | unrated
    kind: int | None = None
    album: int | None = None
    month: str = ""          # 'YYYY' or 'YYYY-MM'
    tag: str = ""
    place: tuple | None = None   # (lat_cell, lon_cell) rounded to 1 decimal
    person: int | None = None
    untagged: bool = False
    sort: str = "taken_new"
    ids: list = field(default_factory=list)  # explicit collection (duplicates etc.); order kept
    use_ids: bool = False


def _like(s: str) -> str:
    return "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def _iso(ts: float) -> str:
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except (OverflowError, OSError, ValueError):
        return "1970-01-01 00:00:00"


class Library:
    def __init__(self, path: str):
        self.path = path
        self._local = threading.local()
        self._write = threading.RLock()
        c = self.conn()
        c.executescript(SCHEMA)
        if "tags_scanned" not in {r[1] for r in c.execute("pragma table_info(images)")}:
            c.execute("alter table images add column tags_scanned integer not null default 0")
        c.commit()

    def conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30)
            c.row_factory = sqlite3.Row
            c.execute("pragma journal_mode=wal")
            c.execute("pragma synchronous=normal")
            c.execute("pragma foreign_keys=on")
            self._local.c = c
        return c

    # ------------------------------------------------------------------ indexing
    def index_folder(self, folder: str, progress=None, cancelled=None) -> dict:
        folder = os.path.abspath(folder)
        if not os.path.isdir(folder):
            raise FileNotFoundError(folder)
        lo, hi = scope_range(folder)
        found: dict[str, tuple] = {}
        bad_dirs: list[str] = []
        stack = [folder]
        while stack:
            if cancelled and cancelled():
                return {"cancelled": True, "total": 0, "added": 0, "updated": 0, "removed": 0, "warning": ""}
            cur = stack.pop()
            try:
                with os.scandir(cur) as it:
                    entries = list(it)
            except OSError:
                bad_dirs.append(canon(cur).rstrip("\\/") + os.sep)
                continue
            for e in entries:
                try:
                    if e.is_dir(follow_symlinks=False):
                        if e.name.lower() not in SKIP_DIRS and not e.name.startswith("."):
                            stack.append(e.path)
                        continue
                    k = kind_of(e.name)
                    if k is None:
                        continue
                    st = e.stat()
                except OSError:
                    continue
                found[canon(e.path)] = (e.path, e.name, k, st.st_size, st.st_mtime_ns, st.st_mtime)
            if progress and len(found) % 500 < 40:
                progress(len(found))
        c = self.conn()
        with self._write:
            existing = {r["path"]: r for r in c.execute(
                "select id, path, size, mtime_ns from images where path>=? and path<?", (lo, hi))}
            warning = ""
            if not found and existing:
                return {"total": 0, "added": 0, "updated": 0, "removed": 0,
                        "warning": "โฟลเดอร์ว่างเปล่า (อาจเป็นไดรฟ์ที่ยังไม่ได้เสียบ) – ไม่ลบข้อมูลเดิม"}
            new_rows, upd_rows = [], []
            for key, (full, name, k, size, mt, mtf) in found.items():
                old = existing.get(key)
                parent = canon(os.path.dirname(full))
                if old is None:
                    new_rows.append((key, os.path.abspath(full), name, parent, size, mt, k, _iso(mtf)))
                elif old["size"] != size or old["mtime_ns"] != mt:
                    upd_rows.append((size, mt, _iso(mtf), os.path.abspath(full), name, old["id"]))
            gone = [r["id"] for p, r in existing.items() if p not in found
                    and not any(p.startswith(b) for b in bad_dirs)]
            c.execute("begin")
            try:
                c.executemany("insert or ignore into images(path,disp,name,dir,size,mtime_ns,kind,taken) "
                              "values(?,?,?,?,?,?,?,?)", new_rows)
                c.executemany("update images set size=?,mtime_ns=?,taken=?,disp=?,name=?,meta_done=0,dhash=null,tags_scanned=0 "
                              "where id=?", upd_rows)
                for i in range(0, len(gone), 500):
                    chunk = gone[i:i + 500]
                    c.execute(f"delete from images where id in ({','.join('?' * len(chunk))})", chunk)
                c.execute("commit")
            except Exception:
                c.execute("rollback")
                raise
            if bad_dirs:
                warning = f"อ่านบางโฟลเดอร์ไม่ได้ {len(bad_dirs)} แห่ง"
        return {"total": len(found), "added": len(new_rows), "updated": len(upd_rows),
                "removed": len(gone), "warning": warning}

    # ------------------------------------------------------------------ metadata
    def pending_meta(self, limit=400, folder: str = ""):
        sql, args = "select id, disp, kind from images where meta_done=0", []
        if folder:
            lo, hi = scope_range(folder)
            sql += " and path>=? and path<?"
            args += [lo, hi]
        return self.conn().execute(sql + " limit ?", args + [limit]).fetchall()

    def count_pending_meta(self) -> int:
        return self.conn().execute("select count(*) from images where meta_done=0").fetchone()[0]

    def save_meta(self, rows):
        """rows: list of (id, meta dict)."""
        c = self.conn()
        with self._write:
            c.execute("begin")
            for iid, m in rows:
                c.execute(
                    "update images set w=?,h=?,taken=coalesce(?,taken),lat=?,lon=?,camera=?,duration=?,"
                    "meta_done=1,dhash=coalesce(?,dhash) where id=?",
                    (m.get("w"), m.get("h"), m.get("taken"), m.get("lat"), m.get("lon"),
                     m.get("camera", ""), m.get("duration"), m.get("dhash"), iid))
            c.execute("commit")

    TAGGABLE_SQL = ("kind=0 and (lower(name) like '%.jpg' or lower(name) like '%.jpeg' or "
                    "lower(name) like '%.tif' or lower(name) like '%.tiff')")

    def pending_tag_scan(self, limit=300):
        return self.conn().execute(
            f"select id, disp from images where tags_scanned=0 and {self.TAGGABLE_SQL} limit ?", (limit,)).fetchall()

    def count_pending_tags(self) -> int:
        return self.conn().execute(
            f"select count(*) from images where tags_scanned=0 and {self.TAGGABLE_SQL}").fetchone()[0]

    def reset_tag_scan(self):
        with self._write:
            self.conn().execute("update images set tags_scanned=0")
            self.conn().commit()

    def save_embedded_tags(self, rows):
        """rows: [(id, [tags])] – merged with tags already in the DB (never removes anything)."""
        c = self.conn()
        with self._write:
            c.execute("begin")
            for iid, tags in rows:
                if tags:
                    r = c.execute("select tags from images where id=?", (iid,)).fetchone()
                    if r is not None:
                        c.execute("update images set tags=? where id=?",
                                  (", ".join(split_tags(split_tags(r[0]) + list(tags))), iid))
                c.execute("update images set tags_scanned=1 where id=?", (iid,))
            c.execute("commit")

    def pending_hash(self, ids=None, limit=2000):
        c = self.conn()
        if ids is not None:
            ids = list(ids)
            out = []
            for i in range(0, len(ids), 500):
                ch = ids[i:i + 500]
                out += c.execute(f"select id, disp from images where kind=0 and dhash is null "
                                 f"and id in ({','.join('?' * len(ch))})", ch).fetchall()
            return out
        return c.execute("select id, disp from images where kind=0 and dhash is null limit ?", (limit,)).fetchall()

    def save_hashes(self, pairs):
        c = self.conn()
        with self._write:
            c.executemany("update images set dhash=? where id=?", pairs)
            c.commit()

    # ------------------------------------------------------------------ queries
    def _where(self, f: Filter):
        w, a = [], []
        if f.folder:
            lo, hi = scope_range(f.folder)
            if f.recursive:
                w.append("path>=? and path<?")
                a += [lo, hi]
            else:
                w.append("dir=?")
                a.append(canon(f.folder))
        for term in f.text.split():
            like = _like(term)
            w.append("(name like ? escape '\\' or tags like ? escape '\\' or camera like ? escape '\\' "
                     "or disp like ? escape '\\')")
            a += [like, like, like, like]
        if f.min_rating:
            w.append("rating>=?")
            a.append(f.min_rating)
        if f.flag == "pick":
            w.append("flag=1")
        elif f.flag == "reject":
            w.append("flag=-1")
        elif f.flag == "not_reject":
            w.append("flag>=0")
        elif f.flag == "unrated":
            w.append("rating=0 and flag=0")
        if f.kind is not None:
            w.append("kind=?")
            a.append(f.kind)
        if f.album is not None:
            w.append("id in (select image_id from album_images where album_id=?)")
            a.append(f.album)
        if f.month:
            w.append("taken like ?")
            a.append(f.month + "%")
        if f.tag:
            w.append("(',' || replace(tags, ', ', ',') || ',') like ? escape '\\'")
            a.append("%," + f.tag.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + ",%")
        if f.place:
            w.append("round(lat,1)=? and round(lon,1)=?")
            a += [f.place[0], f.place[1]]
        if f.untagged:
            w.append("tags=''")
        if f.person is not None:
            w.append("id in (select image_id from faces where person_id=?)")
            a.append(f.person)
        return (" where " + " and ".join(w)) if w else "", a

    def query(self, f: Filter):
        """Return list of tuples (id, disp, kind, rating, flag) in display order."""
        c = self.conn()
        if f.use_ids:
            return self.rows_for_ids(f.ids)
        where, args = self._where(f)
        order = SORTS.get(f.sort, SORTS["taken_new"])
        cur = c.execute(f"select {LIST_COLS} from images{where} order by {order}", args)
        return [tuple(r) for r in cur]

    def rows_for_ids(self, ids):
        c, out, ids = self.conn(), {}, list(ids)
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            for r in c.execute(f"select {LIST_COLS} from images where id in ({','.join('?' * len(ch))})", ch):
                out[r["id"]] = tuple(r)
        return [out[i] for i in ids if i in out]

    def hashes_for(self, ids=None):
        c = self.conn()
        if ids is None:
            return [(r[0], r[1]) for r in c.execute("select id, dhash from images where dhash is not null")]
        ids, out = list(ids), []
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            out += [(r[0], r[1]) for r in c.execute(
                f"select id, dhash from images where dhash is not null and id in ({','.join('?' * len(ch))})", ch)]
        return out

    def infos_for(self, ids):
        c, out, ids = self.conn(), {}, list(ids)
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            for r in c.execute(f"select * from images where id in ({','.join('?' * len(ch))})", ch):
                out[r["id"]] = dict(r)
        return out

    def info(self, iid: int):
        r = self.conn().execute("select * from images where id=?", (iid,)).fetchone()
        return dict(r) if r else None

    def ids_for_paths(self, paths):
        c, out = self.conn(), {}
        for p in paths:
            r = c.execute("select id from images where path=?", (canon(p),)).fetchone()
            if r:
                out[p] = r[0]
        return out

    def stats(self, folder: str = ""):
        where, a = self._where(Filter(folder=folder)) if folder else ("", [])
        r = self.conn().execute(
            f"select count(*), sum(flag=1), sum(flag=-1), sum(rating>0) from images{where}", a).fetchone()
        return {"total": r[0] or 0, "picks": r[1] or 0, "rejects": r[2] or 0, "rated": r[3] or 0}

    # ------------------------------------------------------------------ culling
    def get_states(self, ids):
        c, out, ids = self.conn(), {}, list(ids)
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            for r in c.execute(f"select id, rating, flag from images where id in ({','.join('?' * len(ch))})", ch):
                out[r["id"]] = (r["rating"], r["flag"])
        return out

    def set_states(self, states: dict):
        c = self.conn()
        with self._write:
            c.executemany("update images set rating=?, flag=? where id=?",
                          [(r, f, i) for i, (r, f) in states.items()])
            c.commit()

    # ------------------------------------------------------------------ file ops
    def remove_ids(self, ids):
        c, ids = self.conn(), list(ids)
        with self._write:
            for i in range(0, len(ids), 500):
                ch = ids[i:i + 500]
                c.execute(f"delete from images where id in ({','.join('?' * len(ch))})", ch)
            c.commit()

    def remove_scope(self, folder: str):
        lo, hi = scope_range(folder)
        with self._write:
            self.conn().execute("delete from images where path>=? and path<?", (lo, hi))
            self.conn().commit()

    def relocate(self, iid: int, new_path: str):
        c = self.conn()
        new_path = os.path.abspath(new_path)
        with self._write:
            c.execute("delete from images where path=? and id<>?", (canon(new_path), iid))
            c.execute("update images set path=?, disp=?, name=?, dir=? where id=?",
                      (canon(new_path), new_path, os.path.basename(new_path),
                       canon(os.path.dirname(new_path)), iid))
            c.commit()

    # ------------------------------------------------------------------ tags
    def set_tags(self, iid: int, tags):
        with self._write:
            self.conn().execute("update images set tags=? where id=?", (", ".join(split_tags(tags)), iid))
            self.conn().commit()

    def add_tags(self, ids, tags):
        tags, c = split_tags(tags), self.conn()
        with self._write:
            for iid in ids:
                r = c.execute("select tags from images where id=?", (iid,)).fetchone()
                if r is not None:
                    c.execute("update images set tags=? where id=?",
                              (", ".join(split_tags(split_tags(r[0]) + tags)), iid))
            c.commit()

    def remove_tag(self, ids, tag):
        c = self.conn()
        with self._write:
            for iid in ids:
                r = c.execute("select tags from images where id=?", (iid,)).fetchone()
                if r is not None:
                    keep = [t for t in split_tags(r[0]) if t.casefold() != tag.casefold()]
                    c.execute("update images set tags=? where id=?", (", ".join(keep), iid))
            c.commit()

    def tags_map(self):
        return {r[0]: r[1] for r in self.conn().execute("select id, tags from images where tags<>''")}

    def tags_of(self, ids):
        """{tag: number of the given images having it} (display spelling of the first occurrence)."""
        c, counts, ids = self.conn(), {}, list(ids)
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            for (t,) in c.execute(f"select tags from images where tags<>'' and id in ({','.join('?' * len(ch))})", ch):
                for tag in split_tags(t):
                    k = tag.casefold()
                    name, n = counts.get(k, (tag, 0))
                    counts[k] = (name, n + 1)
        return sorted(counts.values(), key=lambda x: (-x[1], x[0].casefold()))

    def remove_tags(self, ids, tags):
        """Remove several tags (case-insensitive) from several images. Returns ids that really changed."""
        drop = {t.casefold() for t in tags}
        c, changed = self.conn(), []
        with self._write:
            c.execute("begin")
            for iid in ids:
                r = c.execute("select tags from images where id=?", (iid,)).fetchone()
                if r is None:
                    continue
                cur = split_tags(r[0])
                keep = [t for t in cur if t.casefold() not in drop]
                if len(keep) != len(cur):
                    c.execute("update images set tags=? where id=?", (", ".join(keep), iid))
                    changed.append(iid)
            c.execute("commit")
        return changed

    def ids_with_tag(self, tag):
        return [r[0] for r in self.query(Filter(tag=tag))]

    def rename_tag(self, old, new):
        """Rename (or merge into an existing tag) on every image. Returns affected ids."""
        ids = self.ids_with_tag(old)
        c = self.conn()
        with self._write:
            c.execute("begin")
            for iid in ids:
                cur = split_tags(c.execute("select tags from images where id=?", (iid,)).fetchone()[0])
                out = [new if t.casefold() == old.casefold() else t for t in cur]
                c.execute("update images set tags=? where id=?", (", ".join(split_tags(out)), iid))
            c.execute("commit")
        return ids

    def tag_counts(self):
        counts: dict[str, int] = {}
        for (t,) in self.conn().execute("select tags from images where tags<>''"):
            for tag in split_tags(t):
                counts[tag] = counts.get(tag, 0) + 1
        return sorted(counts.items(), key=lambda x: (-x[1], x[0].casefold()))

    # ------------------------------------------------------------------ sidebar data
    def folder_counts(self, root: str):
        lo, hi = scope_range(root)
        return [(r["dir"], r["n"], r["d"]) for r in self.conn().execute(
            "select dir, count(*) n, min(disp) d from images where path>=? and path<? group by dir", (lo, hi))]

    def roots_overview(self):
        """Distinct top folders already indexed – used to restore the last session's libraries."""
        return [r[0] for r in self.conn().execute("select distinct dir from images limit 5000")]

    def month_counts(self, folder: str = ""):
        where, a = self._where(Filter(folder=folder)) if folder else ("", [])
        return [(r[0], r[1]) for r in self.conn().execute(
            f"select substr(taken,1,7) m, count(*) from images{where} group by m order by m desc", a)]

    def place_counts(self, folder: str = ""):
        where, a = self._where(Filter(folder=folder)) if folder else ("", [])
        where += (" and " if where else " where ") + "lat is not null and lon is not null"
        return [(r[0], r[1], r[2]) for r in self.conn().execute(
            f"select round(lat,1), round(lon,1), count(*) from images{where} "
            "group by round(lat,1), round(lon,1) order by count(*) desc limit 500", a)]

    # ------------------------------------------------------------------ albums
    def albums(self):
        return [(r[0], r[1], r[2]) for r in self.conn().execute(
            "select a.id, a.name, count(ai.image_id) from albums a "
            "left join album_images ai on ai.album_id=a.id group by a.id order by a.name collate nocase")]

    def create_album(self, name: str) -> int:
        c = self.conn()
        with self._write:
            c.execute("insert or ignore into albums(name) values(?)", (name.strip(),))
            c.commit()
            return c.execute("select id from albums where name=?", (name.strip(),)).fetchone()[0]

    def rename_album(self, aid, name):
        with self._write:
            self.conn().execute("update or ignore albums set name=? where id=?", (name.strip(), aid))
            self.conn().commit()

    def delete_album(self, aid):
        with self._write:
            self.conn().execute("delete from albums where id=?", (aid,))
            self.conn().commit()

    def album_add(self, aid, ids):
        with self._write:
            self.conn().executemany("insert or ignore into album_images values(?,?)", [(aid, i) for i in ids])
            self.conn().commit()

    def album_remove(self, aid, ids):
        with self._write:
            self.conn().executemany("delete from album_images where album_id=? and image_id=?",
                                    [(aid, i) for i in ids])
            self.conn().commit()

    # ------------------------------------------------------------------ import from Photos Viewer 4/5
    def import_v5(self, old_db: str) -> dict:
        """Copy tags, favourites (-> pick) and albums from a v4/v5 photos.sqlite3."""
        src = sqlite3.connect(f"file:{old_db}?mode=ro", uri=True)
        src.row_factory = sqlite3.Row
        cols = {r[1] for r in src.execute("pragma table_info(images)")}
        sel = "path, tags" + (", favorite" if "favorite" in cols else ", 0 as favorite")
        n_tags = n_fav = 0
        c = self.conn()
        with self._write:
            c.execute("begin")
            for r in src.execute(f"select {sel} from images"):
                row = c.execute("select id, tags, flag from images where path=?", (canon(r["path"]),)).fetchone()
                if not row:
                    continue
                tags = split_tags(r["tags"] or "")
                if tags and not row["tags"]:
                    c.execute("update images set tags=? where id=?", (", ".join(tags), row["id"]))
                    n_tags += 1
                if r["favorite"] and row["flag"] == 0:
                    c.execute("update images set flag=1 where id=?", (row["id"],))
                    n_fav += 1
            n_alb = 0
            tables = {r[0] for r in src.execute("select name from sqlite_master where type='table'")}
            if {"albums", "album_images"} <= tables:

                for a in src.execute("select * from albums"):
                    aid = c.execute("insert or ignore into albums(name) values(?)", (a["name"],)).lastrowid
                    aid = c.execute("select id from albums where name=?", (a["name"],)).fetchone()[0]
                    for m in src.execute("select path from album_images where album_id=?", (a["id"],)):
                        row = c.execute("select id from images where path=?", (canon(m["path"]),)).fetchone()
                        if row:
                            c.execute("insert or ignore into album_images values(?,?)", (aid, row[0]))
                    n_alb += 1
            c.execute("commit")
        src.close()
        return {"tags": n_tags, "favorites": n_fav, "albums": n_alb}
