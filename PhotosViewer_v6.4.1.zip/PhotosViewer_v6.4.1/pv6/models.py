"""Gallery model + painter. Rows are tuples (id, disp, kind, rating, flag)."""
from __future__ import annotations

import os

from PyQt6.QtCore import QAbstractListModel, QMimeData, QModelIndex, QPointF, QRectF, QSize, Qt, QUrl
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import QStyle, QStyledItemDelegate

IdRole = Qt.ItemDataRole.UserRole + 1
PathRole = Qt.ItemDataRole.UserRole + 2
KindRole = Qt.ItemDataRole.UserRole + 3
RatingRole = Qt.ItemDataRole.UserRole + 4
FlagRole = Qt.ItemDataRole.UserRole + 5
GroupRole = Qt.ItemDataRole.UserRole + 6

GROUP_COLORS = ["#e5484d", "#f5a524", "#30a46c", "#3e63dd", "#ab4aba", "#12a594", "#d6409f", "#8e8c99"]


class PhotoModel(QAbstractListModel):
    def __init__(self):
        super().__init__()
        self.rows: list[tuple] = []
        self.pos: dict[int, int] = {}
        self.group: dict[int, int] = {}
        self.tags: dict[int, str] = {}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def data(self, idx, role=Qt.ItemDataRole.DisplayRole):
        if not idx.isValid() or idx.row() >= len(self.rows):
            return None
        r = self.rows[idx.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return os.path.basename(r[1])
        if role == Qt.ItemDataRole.ToolTipRole:
            return r[1]
        if role == IdRole:
            return r[0]
        if role == PathRole:
            return r[1]
        if role == KindRole:
            return r[2]
        if role == RatingRole:
            return r[3]
        if role == FlagRole:
            return r[4]
        if role == GroupRole:
            return self.group.get(r[0])
        return None

    def flags(self, idx):
        f = super().flags(idx)
        return f | Qt.ItemFlag.ItemIsDragEnabled if idx.isValid() else f

    def mimeTypes(self):
        return ["text/uri-list"]

    def mimeData(self, indexes):
        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(self.rows[i.row()][1]) for i in indexes if i.isValid()])
        return md

    def set_rows(self, rows, group=None):
        self.beginResetModel()
        self.rows = list(rows)
        self.pos = {r[0]: i for i, r in enumerate(self.rows)}
        self.group = group or {}
        self.endResetModel()

    def row_of(self, iid: int) -> int:
        return self.pos.get(iid, -1)

    def id_at(self, row: int):
        return self.rows[row][0] if 0 <= row < len(self.rows) else None

    def path_at(self, row: int):
        return self.rows[row][1] if 0 <= row < len(self.rows) else None

    def row_data(self, row: int):
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def set_state(self, iid: int, rating: int, flag: int):
        row = self.pos.get(iid)
        if row is None:
            return
        r = self.rows[row]
        self.rows[row] = (r[0], r[1], r[2], rating, flag)
        i = self.index(row)
        self.dataChanged.emit(i, i)

    def notify(self, iid: int):
        row = self.pos.get(iid)
        if row is not None:
            i = self.index(row)
            self.dataChanged.emit(i, i)

    def remove_ids(self, ids):
        rows = sorted((self.pos[i] for i in set(ids) if i in self.pos), reverse=True)
        runs, start, prev = [], None, None
        for r in rows:                       # contiguous runs, highest first
            if start is None:
                start = prev = r
            elif r == prev - 1:
                prev = r
            else:
                runs.append((prev, start))
                start = prev = r
        if start is not None:
            runs.append((prev, start))
        for lo, hi in runs:
            self.beginRemoveRows(QModelIndex(), lo, hi)
            del self.rows[lo:hi + 1]
            self.endRemoveRows()
        self.pos = {r[0]: i for i, r in enumerate(self.rows)}


class PhotoDelegate(QStyledItemDelegate):
    def __init__(self, cache, compact=False, parent=None):
        super().__init__(parent)
        self.cache = cache
        self.compact = compact
        self.cell = 170
        self.show_names = False
        self.show_tags = False
        self.dark = True

    def label_h(self):
        if self.compact:
            return 0
        return 18 * (int(self.show_names) + int(self.show_tags))

    def sizeHint(self, opt, idx):
        return QSize(self.cell, self.cell + self.label_h())

    def paint(self, p: QPainter, opt, idx):
        r = QRectF(opt.rect).adjusted(3, 3, -3, -3)
        iid = idx.data(IdRole)
        rating, flag, kind = idx.data(RatingRole), idx.data(FlagRole), idx.data(KindRole)
        sel = bool(opt.state & QStyle.StateFlag.State_Selected)
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        bg = QColor("#2a2b30" if self.dark else "#e6e8ee")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#3b5bdb") if sel else bg)
        p.drawRoundedRect(r, 6, 6)
        box = r.adjusted(3, 3, -3, -3 - self.label_h())
        pm = self.cache.get(iid)
        if pm is not None:
            s = pm.size().scaled(box.size().toSize(), Qt.AspectRatioMode.KeepAspectRatio)
            tr = QRectF(box.center().x() - s.width() / 2, box.center().y() - s.height() / 2, s.width(), s.height())
            p.setOpacity(0.3 if flag < 0 else 1.0)
            p.drawPixmap(tr.toRect(), pm)
            p.setOpacity(1.0)
        else:
            p.setPen(QColor("#888"))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, "⚠" if iid in self.cache.failed else "…")
        small = self.compact or self.cell < 110
        f = QFont(opt.font)
        f.setPointSizeF(max(7.0, f.pointSizeF() - (2 if small else 1)))
        f.setBold(True)
        p.setFont(f)
        fm = p.fontMetrics()
        if flag:
            col = QColor("#30a46c" if flag > 0 else "#e5484d")
            d = 16 if not small else 12
            c = QRectF(box.left() + 3, box.top() + 3, d, d)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col)
            p.drawEllipse(c)
            p.setPen(QColor("white"))
            p.drawText(c, Qt.AlignmentFlag.AlignCenter, "✓" if flag > 0 else "✕")
        if rating and not small:
            txt = "★" * rating
            w = fm.horizontalAdvance(txt) + 8
            pill = QRectF(box.left() + 3, box.bottom() - fm.height() - 4, w, fm.height() + 2)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            p.drawRoundedRect(pill, 4, 4)
            p.setPen(QColor("#ffc53d"))
            p.drawText(pill, Qt.AlignmentFlag.AlignCenter, txt)
        elif rating and small:
            p.setPen(QColor("#ffc53d"))
            p.drawText(QPointF(box.left() + 3, box.bottom() - 3), f"★{rating}")
        if kind == 1:
            b = QRectF(box.right() - 26, box.bottom() - 18, 24, 16)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 170))
            p.drawRoundedRect(b, 4, 4)
            p.setPen(QColor("white"))
            p.drawText(b, Qt.AlignmentFlag.AlignCenter, "▶")
        g = idx.data(GroupRole)
        if g is not None:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(GROUP_COLORS[g % len(GROUP_COLORS)]))
            gb = QRectF(box.right() - 22, box.top() + 3, 20, 14)
            p.drawRoundedRect(gb, 4, 4)
            p.setPen(QColor("white"))
            p.drawText(gb, Qt.AlignmentFlag.AlignCenter, str(g + 1))
        if sel:
            p.setPen(QPen(QColor("#74c0fc"), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(r, 6, 6)
        if self.label_h():
            f2 = QFont(opt.font)
            f2.setPointSizeF(max(7.0, f2.pointSizeF() - 1.5))
            p.setFont(f2)
            fm2 = p.fontMetrics()
            y = r.bottom() - self.label_h()
            w = r.width() - 6
            if self.show_names:
                p.setPen(QColor("#ddd" if self.dark or sel else "#222"))
                p.drawText(QRectF(r.left() + 3, y, w, 18), Qt.AlignmentFlag.AlignCenter,
                           fm2.elidedText(idx.data(Qt.ItemDataRole.DisplayRole), Qt.TextElideMode.ElideMiddle, int(w)))
                y += 18
            if self.show_tags:
                tg = getattr(idx.model(), "tags", {}).get(iid, "")
                if tg:
                    p.setPen(QColor("#ffffff" if sel else ("#74c0fc" if self.dark else "#1c5fb0")))
                    txt = "# " + tg
                else:
                    p.setPen(QColor("#ffd8a8" if sel else "#e8590c" if not self.dark else "#ff922b"))
                    txt = "ยังไม่มีแท็ก"
                p.drawText(QRectF(r.left() + 3, y, w, 18), Qt.AlignmentFlag.AlignCenter,
                           fm2.elidedText(txt, Qt.TextElideMode.ElideRight, int(w)))
        p.restore()
