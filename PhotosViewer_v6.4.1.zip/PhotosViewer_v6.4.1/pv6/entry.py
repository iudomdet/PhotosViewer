import os
import sys
import traceback


def main():
    # harmless Qt warning about odd ICC profiles embedded in some photos
    os.environ.setdefault("QT_LOGGING_RULES", "qt.gui.icc*=false")
    from PyQt6.QtWidgets import QApplication, QMessageBox
    from . import APP_NAME
    from .util import app_data_dir

    log = os.path.join(app_data_dir(), "error.log")

    def hook(et, ev, tb):
        text = "".join(traceback.format_exception(et, ev, tb))
        try:
            with open(log, "a", encoding="utf-8") as fh:
                fh.write(text + "\n")
        except OSError:
            pass
        sys.__excepthook__(et, ev, tb)

    sys.excepthook = hook
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    from .main_window import MainWindow
    try:
        win = MainWindow()
    except Exception:
        hook(*sys.exc_info())
        QMessageBox.critical(None, APP_NAME, "เปิดโปรแกรมไม่สำเร็จ ดูรายละเอียดใน\n" + log)
        return 1
    win.show()
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            win.add_root(a)
    return app.exec()
