APP_NAME = "Photos Viewer 6"
__version__ = "6.4.1"
