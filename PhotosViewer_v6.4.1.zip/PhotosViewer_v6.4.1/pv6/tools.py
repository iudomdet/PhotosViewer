"""Pure-python logic for duplicates, ranking, file transfer and export (no Qt)."""
from __future__ import annotations

import os
import shutil

from . import media


def cluster_hashes(pairs, threshold=6, cancelled=None):
    """pairs: [(id, signed_dhash)] -> list of groups (lists of ids) whose hashes are within *threshold* bits.
    Multi-index pigeonhole: split 64 bits into threshold+1 blocks; items sharing a block are candidates."""
    n = len(pairs)
    if n < 2:
        return []
    u = [(h + (1 << 64)) if h < 0 else h for _, h in pairs]
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    blocks = threshold + 1
    bounds = [round(i * 64 / blocks) for i in range(blocks + 1)]
    for b in range(blocks):
        if cancelled and cancelled():
            return []
        lo, hi = bounds[b], bounds[b + 1]
        mask = (1 << (hi - lo)) - 1
        buckets: dict[int, list[int]] = {}
        for i, h in enumerate(u):
            buckets.setdefault((h >> lo) & mask, []).append(i)
        for members in buckets.values():
            m = len(members)
            if m < 2:
                continue
            if m > 600:            # degenerate bucket (flat images): compare against a window only
                members = members[:600]
                m = 600
            for x in range(m):
                hx = u[members[x]]
                for y in range(x + 1, m):
                    if bin(hx ^ u[members[y]]).count("1") <= threshold:
                        a, c = find(members[x]), find(members[y])
                        if a != c:
                            parent[a] = c
    groups: dict[int, list[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(pairs[i][0])
    out = [g for g in groups.values() if len(g) > 1]
    out.sort(key=lambda g: -len(g))
    return out


def similar_to(target_hash, pairs, max_dist=12):
    t = (target_hash + (1 << 64)) if target_hash < 0 else target_hash
    res = []
    for iid, h in pairs:
        hh = (h + (1 << 64)) if h < 0 else h
        d = bin(t ^ hh).count("1")
        if d <= max_dist:
            res.append((d, iid))
    res.sort()
    return [i for _, i in res]


def best_of(infos: list[dict]) -> int:
    """Index of the member to KEEP: pick flag > rating > resolution > sharpness > size > earliest name."""
    def key(i):
        d = infos[i]
        res = (d.get("w") or 0) * (d.get("h") or 0)
        sharp = media.sharpness(d["disp"]) if d.get("kind") == 0 else 0
        return (d.get("flag", 0) > 0, d.get("rating", 0), res, round(sharp, 1), d.get("size", 0), d["name"] == d["name"])
    return max(range(len(infos)), key=lambda i: (key(i), -i))


def unique_dest(dst_dir: str, name: str) -> str:
    base, ext = os.path.splitext(name)
    dst = os.path.join(dst_dir, name)
    n = 1
    while os.path.exists(dst):
        dst = os.path.join(dst_dir, f"{base}_{n}{ext}")
        n += 1
    return dst


def transfer_files(items, dest_dir: str, move: bool, task=None):
    """items: [(id, src_path)] -> ([(id, src, dst)], [(src, error)]). Never overwrites existing files."""
    done, failed = [], []
    os.makedirs(dest_dir, exist_ok=True)
    for n, (iid, src) in enumerate(items):
        if task and task.is_cancelled():
            break
        try:
            if os.path.dirname(os.path.abspath(src)) == os.path.abspath(dest_dir):
                continue
            dst = unique_dest(dest_dir, os.path.basename(src))
            if move:
                shutil.move(src, dst)
            else:
                shutil.copy2(src, dst)
            done.append((iid, src, dst))
        except Exception as exc:
            failed.append((src, str(exc)))
        if task:
            task.progress.emit((n + 1, len(items)))
    return done, failed


def export_files(items, dest_dir, long_edge, quality, xmp, task=None):
    """items: [(id, path, kind, rating, flag)] -> (count, errors). Photos are re-encoded; videos copied."""
    os.makedirs(dest_dir, exist_ok=True)
    ok, errs = 0, []
    for n, (iid, path, kind, rating, flag) in enumerate(items):
        if task and task.is_cancelled():
            break
        try:
            if kind == 1:
                dst = unique_dest(dest_dir, os.path.basename(path))
                shutil.copy2(path, dst)
            else:
                dst = media.export_copy(path, dest_dir, long_edge, quality, kind)
            if xmp:
                media.write_xmp_rating(dst, rating, flag)
            ok += 1
        except Exception as exc:
            errs.append((path, str(exc)))
        if task:
            task.progress.emit((n + 1, len(items)))
    return ok, errs
