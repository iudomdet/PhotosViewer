"""Background machinery: thumbnail cache, full-size image loader, generic task thread."""
from __future__ import annotations

import os
import threading
import traceback
from collections import OrderedDict

from PyQt6.QtCore import QObject, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QImage, QPixmap

from . import media


def pil_to_qimage(im) -> QImage:
    im = im.convert("RGB")
    w, h = im.size
    return QImage(im.tobytes("raw", "RGB"), w, h, w * 3, QImage.Format.Format_RGB888).copy()


class Task(QThread):
    """Run fn(task) in a thread. fn may call task.progress.emit(x) and should poll task.cancelled."""
    progress = pyqtSignal(object)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn
        self.cancelled = False

    def cancel(self):
        self.cancelled = True

    def is_cancelled(self):
        return self.cancelled

    def run(self):
        try:
            self.done.emit(self.fn(self))
        except Exception:
            self.failed.emit(traceback.format_exc())


class ThumbCache(QObject):
    """Memory LRU of QPixmaps + worker threads that fill it (visible items first)."""
    updated = pyqtSignal(int)
    _loaded = pyqtSignal(int, QImage)

    def __init__(self, cache_dir: str, max_items=4000):
        super().__init__()
        self.dir = cache_dir
        self.max = max_items
        self.pix: OrderedDict[int, QPixmap] = OrderedDict()
        self.failed: set[int] = set()
        self._cond = threading.Condition()
        self._queue: list = []
        self._inflight: set[int] = set()
        self._stop = False
        self._loaded.connect(self._on_loaded)
        n = max(2, min(6, (os.cpu_count() or 4) - 1))
        self._threads = [threading.Thread(target=self._run, daemon=True) for _ in range(n)]
        for t in self._threads:
            t.start()

    def get(self, iid: int):
        p = self.pix.get(iid)
        if p is not None:
            self.pix.move_to_end(iid)
        return p

    def want(self, items):
        """items: [(id, path, kind)] in priority order. Replaces the pending queue."""
        with self._cond:
            self._queue = [it for it in items if it[0] not in self.pix and it[0] not in self.failed
                           and it[0] not in self._inflight]
            self._cond.notify_all()

    def forget(self, iid: int):
        self.pix.pop(iid, None)
        self.failed.discard(iid)

    def clear_failed(self):
        self.failed.clear()

    def stop(self):
        with self._cond:
            self._stop = True
            self._queue = []
            self._cond.notify_all()

    def _run(self):
        while True:
            with self._cond:
                while not self._queue and not self._stop:
                    self._cond.wait()
                if self._stop:
                    return
                iid, path, kind = self._queue.pop(0)
                self._inflight.add(iid)
            img = QImage()
            try:
                f = media.ensure_thumb(self.dir, path, kind, os.stat(path).st_mtime_ns)
                if f:
                    img = QImage(f)
            except Exception:
                pass
            with self._cond:
                self._inflight.discard(iid)
            self._loaded.emit(iid, img)

    def _on_loaded(self, iid: int, img: QImage):
        if img.isNull():
            self.failed.add(iid)
        else:
            self.pix[iid] = QPixmap.fromImage(img)
            while len(self.pix) > self.max:
                self.pix.popitem(last=False)
        self.updated.emit(iid)


class ViewLoader(QObject):
    """Loads display-size (fit) and full-resolution images; keeps a few in memory; supports prefetch."""
    loaded = pyqtSignal(object, int, bool, int, int, QImage)
    _res = pyqtSignal(object, int, bool, int, int, QImage)

    def __init__(self, fit_edge=2800, threads=2):
        super().__init__()
        self.fit_edge = fit_edge
        self.cache: OrderedDict = OrderedDict()
        self._cond = threading.Condition()
        self._queue: list = []
        self._inflight: set = set()
        self._stop = False
        self._res.connect(self._on_res)
        for _ in range(threads):
            threading.Thread(target=self._run, daemon=True).start()

    def cached(self, iid: int, full: bool):
        v = self.cache.get((iid, full))
        if v is not None:
            self.cache.move_to_end((iid, full))
        return v

    def request(self, tag, iid: int, path: str, full=False, urgent=True):
        hit = self.cached(iid, full)
        if hit is not None:
            ow, oh, img = hit
            if tag != "prefetch":
                QTimer.singleShot(0, lambda: self.loaded.emit(tag, iid, full, ow, oh, img))
            return
        key = (iid, full)
        with self._cond:
            self._queue = [j for j in self._queue if (j[1], j[3]) != key]
            if key in self._inflight and not urgent:
                return
            job = (tag, iid, path, full)
            if urgent:
                self._queue.insert(0, job)
            else:
                self._queue.append(job)
            self._cond.notify()

    def drop_prefetch(self):
        with self._cond:
            self._queue = [j for j in self._queue if j[0] != "prefetch"]

    def forget(self, iid: int):
        for k in [(iid, True), (iid, False)]:
            self.cache.pop(k, None)

    def stop(self):
        with self._cond:
            self._stop = True
            self._queue = []
            self._cond.notify_all()

    def _run(self):
        while True:
            with self._cond:
                while not self._queue and not self._stop:
                    self._cond.wait()
                if self._stop:
                    return
                tag, iid, path, full = self._queue.pop(0)
                self._inflight.add((iid, full))
            img, ow, oh = QImage(), 0, 0
            try:
                ow, oh, pim = media.load_for_view(path, 0 if full else self.fit_edge)
                img = pil_to_qimage(pim)
            except Exception:
                pass
            with self._cond:
                self._inflight.discard((iid, full))
            self._res.emit(tag, iid, full, ow, oh, img)

    def _on_res(self, tag, iid, full, ow, oh, img):
        if not img.isNull():
            self.cache[(iid, full)] = (ow, oh, img)
            limit = 3 if full else 14
            keys = [k for k in self.cache if k[1] == full]
            for k in keys[:-limit]:
                self.cache.pop(k, None)
        self.loaded.emit(tag, iid, full, ow, oh, img)
