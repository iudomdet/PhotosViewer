"""Main window: gallery, sidebar, culling, viewer/compare switching, background jobs."""
from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor

from PyQt6.QtCore import QEvent, QSettings, QSize, Qt, QTimer
from PyQt6.QtGui import QAction, QGuiApplication, QKeySequence
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDockWidget, QFileDialog,
                             QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListView, QListWidget,
                             QListWidgetItem, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton,
                             QSlider, QStackedWidget, QTabWidget, QToolBar, QTreeWidget, QTreeWidgetItem,
                             QVBoxLayout, QWidget)

from . import APP_NAME, __version__, media, tools, theme, winprops
from .db import Filter, Library
from .dialogs import ExportDialog, ShortcutsDialog, TagEditDialog, TagRemoveDialog
from .models import IdRole, PhotoDelegate, PhotoModel
from .util import (app_data_dir, canon, human_size, open_default, recycle, reveal_in_explorer, split_tags)
from .viewer import ComparePage, ViewerPage
from .workers import Task, ThumbCache, ViewLoader

SORT_LABELS = [("taken_new", "วันที่ถ่าย (ใหม่→เก่า)"), ("taken_old", "วันที่ถ่าย (เก่า→ใหม่)"),
               ("name", "ชื่อไฟล์ A→Z"), ("name_desc", "ชื่อไฟล์ Z→A"), ("mtime", "แก้ไขล่าสุด"),
               ("size", "ขนาดไฟล์"), ("rating", "ดาวมาก→น้อย")]
FLAG_LABELS = [("any", "ธง: ทั้งหมด"), ("pick", "✓ Pick"), ("reject", "✕ Reject"),
               ("not_reject", "ไม่รวม Reject"), ("unrated", "ยังไม่คัด")]
PAGE_GALLERY, PAGE_VIEWER, PAGE_COMPARE = 0, 1, 2
UR = Qt.ItemDataRole.UserRole


class MainWindow(QMainWindow):
    def __init__(self, data_dir: str | None = None):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  v{__version__}")
        self.resize(1360, 860)
        self.data_dir = data_dir or app_data_dir()
        os.makedirs(self.data_dir, exist_ok=True)
        self.settings = QSettings("PhotosViewer6", "PhotosViewer6")
        self.lib = Library(os.path.join(self.data_dir, "library.db"))
        self.thumbs = ThumbCache(os.path.join(self.data_dir, "thumbs"))
        self.loader = ViewLoader()
        self.model = PhotoModel()
        self.tasks: list[Task] = []
        self.roots: list[str] = [r for r in (self.settings.value("roots", []) or []) if r]
        if isinstance(self.roots, str):
            self.roots = [self.roots]
        self.scope: tuple = ("all",)
        self.collection: dict | None = None
        self.quick_tags = [t for t in (self.settings.value("quick_tags", []) or []) if t]
        if isinstance(self.quick_tags, str):
            self.quick_tags = [self.quick_tags]
        self.undo_stack: list = []
        self.redo_stack: list = []
        self.mode = PAGE_GALLERY
        self.prev_mode = PAGE_GALLERY
        self.dark = self.settings.value("dark", True, bool)
        self.auto_advance = self.settings.value("auto_advance", True, bool)
        self.index_task: Task | None = None
        self.meta_task: Task | None = None
        self._pending_roots: list[str] = []
        self._info_cache: dict[int, dict] = {}
        self._build_ui()
        self._build_actions()
        self._apply_theme()
        self._restore()
        self.thumbs.updated.connect(self.model.notify)
        self.thumbs.updated.connect(self._thumb_done)
        self.reload()
        self.refresh_sidebar()
        QTimer.singleShot(200, self._startup_scan)

    # ================================================================== UI
    def _build_ui(self):
        # toolbar
        tb = QToolBar("main")
        tb.setMovable(False)
        tb.setIconSize(QSize(18, 18))
        self.addToolBar(tb)
        self.toolbar = tb
        self.search = QLineEdit()
        self.search.setPlaceholderText("ค้นหาชื่อไฟล์ / แท็ก / กล้อง …")
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(240)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.timeout.connect(self._filters_changed)
        self.search.textChanged.connect(lambda *_: self._search_timer.start(250))
        self.cb_rating = QComboBox()
        self.cb_rating.addItem("ดาว: ทั้งหมด", 0)
        for n in range(1, 6):
            self.cb_rating.addItem("★" * n + " ขึ้นไป", n)
        self.cb_flag = QComboBox()
        for k, t in FLAG_LABELS:
            self.cb_flag.addItem(t, k)
        self.cb_kind = QComboBox()
        self.cb_kind.addItem("รูป+วิดีโอ", None)
        self.cb_kind.addItem("เฉพาะรูป", 0)
        self.cb_kind.addItem("เฉพาะวิดีโอ", 1)
        self.cb_sort = QComboBox()
        for k, t in SORT_LABELS:
            self.cb_sort.addItem(t, k)
        self.chk_rec = QCheckBox("รวมโฟลเดอร์ย่อย")
        self.chk_rec.setChecked(True)
        self.chk_names = QCheckBox("ชื่อไฟล์")
        self.chk_tags = QCheckBox("แท็ก")
        self.chk_untagged = QCheckBox("เฉพาะที่ยังไม่มีแท็ก")
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(80, 340)
        self.slider.setValue(170)
        self.slider.setFixedWidth(120)
        for w in (self.cb_rating, self.cb_flag, self.cb_kind, self.cb_sort):
            w.currentIndexChanged.connect(self._filters_changed)
        self.chk_rec.toggled.connect(self._filters_changed)
        self.chk_names.toggled.connect(self._names_toggled)
        self.chk_tags.toggled.connect(self._names_toggled)
        self.chk_untagged.toggled.connect(self._filters_changed)
        self.slider.valueChanged.connect(self._cell_changed)
        tb.addWidget(self.search)
        for w in (self.cb_rating, self.cb_flag, self.cb_kind, self.cb_sort, self.chk_rec, self.chk_names, self.chk_tags, self.chk_untagged):
            tb.addWidget(w)
        tb.addWidget(QLabel(" 🔍"))
        tb.addWidget(self.slider)

        # sidebar
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        self.tabs.setUsesScrollButtons(False)
        self.tabs.tabBar().setExpanding(False)
        self.tree_folders = QTreeWidget()
        self.tree_dates = QTreeWidget()
        for t in (self.tree_folders, self.tree_dates):
            t.setHeaderHidden(True)
        self.list_albums, self.list_places, self.list_tags, self.list_people = (
            QListWidget(), QListWidget(), QListWidget(), QListWidget())
        for w, name in ((self.tree_folders, "โฟลเดอร์"), (self.tree_dates, "วันที่"), (self.list_albums, "อัลบั้ม"),
                        (self.list_places, "ที่ถ่าย"), (self.list_tags, "แท็ก"), (self.list_people, "คน")):
            self.tabs.addTab(w, name)
        self.tree_folders.itemClicked.connect(self._folder_clicked)
        self.tree_dates.itemClicked.connect(lambda it, _: self._set_scope(("month", it.data(0, UR))) if it.data(0, UR) else None)
        self.list_albums.itemClicked.connect(lambda it: self._set_scope(("album", it.data(UR))))
        self.list_places.itemClicked.connect(lambda it: self._set_scope(("place", it.data(UR))))
        self.list_tags.itemClicked.connect(lambda it: self._set_scope(("tag", it.data(UR))))
        self.list_people.itemClicked.connect(lambda it: self._set_scope(("person", it.data(UR))))
        self.list_albums.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_albums.customContextMenuRequested.connect(self._album_menu)
        self.tree_folders.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree_folders.customContextMenuRequested.connect(self._folder_menu)
        self.list_tags.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_tags.customContextMenuRequested.connect(self._tag_menu)
        self.list_people.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_people.customContextMenuRequested.connect(self._people_menu)
        self.dock = QDockWidget("คลังรูป")
        self.dock.setWidget(self.tabs)
        self.dock.setFeatures(QDockWidget.DockWidgetFeature.NoDockWidgetFeatures)
        self.dock.setTitleBarWidget(QWidget())
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.dock)
        self.dock.setMinimumWidth(300)

        # gallery page
        self.delegate = PhotoDelegate(self.thumbs)
        self.view = QListView()
        self.view.setModel(self.model)
        self.view.setItemDelegate(self.delegate)
        self.view.setViewMode(QListView.ViewMode.IconMode)
        self.view.setResizeMode(QListView.ResizeMode.Adjust)
        self.view.setMovement(QListView.Movement.Static)
        self.view.setUniformItemSizes(True)
        self.view.setSpacing(0)
        self.view.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.view.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.view.setDragEnabled(True)
        self.view.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        self.view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.view.customContextMenuRequested.connect(self._gallery_menu)
        self.view.doubleClicked.connect(lambda i: self.enter_viewer(i.row()))
        self.view.verticalScrollBar().valueChanged.connect(lambda *_: self._vis_timer.start(30))
        self.view.selectionModel().selectionChanged.connect(lambda *_: self._update_status())
        self._vis_timer = QTimer(self)
        self._vis_timer.setSingleShot(True)
        self._vis_timer.timeout.connect(self._request_visible)
        self.model.modelReset.connect(lambda: self._vis_timer.start(30))
        self.model.rowsRemoved.connect(lambda *_: self._vis_timer.start(30))
        self.empty = QLabel()
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setWordWrap(True)
        self.banner = QWidget()
        bl = QHBoxLayout(self.banner)
        bl.setContentsMargins(0, 0, 0, 0)
        self.banner_label = QLabel()
        self.banner_label.setObjectName("banner")
        bl.addWidget(self.banner_label, 1)
        self.btn_keepbest = QPushButton("เลือกตัวที่ควรลบ (เก็บตัวดีที่สุด)")
        self.btn_keepbest.clicked.connect(self.select_all_but_best)
        self.btn_delsel = QPushButton("ลบที่เลือก")
        self.btn_delsel.clicked.connect(lambda: self.delete_ids(self.selected_ids()))
        self.btn_close_coll = QPushButton("ปิดผลลัพธ์")
        self.btn_close_coll.clicked.connect(self.close_collection)
        for b in (self.btn_keepbest, self.btn_delsel, self.btn_close_coll):
            bl.addWidget(b)
        self.banner.hide()
        gal = QWidget()
        gl = QVBoxLayout(gal)
        gl.setContentsMargins(0, 0, 0, 0)
        gl.setSpacing(0)
        gl.addWidget(self.banner)
        gl.addWidget(self.view, 1)
        gl.addWidget(self.empty, 1)

        self.viewer = ViewerPage(self.model, self.loader, self.thumbs)
        self.viewer.info_provider = self.info_of
        self.viewer.navigate.connect(self.show_viewer_row)
        self.viewer.closeRequested.connect(self.leave_viewer)
        self.viewer.openExternal.connect(open_default)
        self.compare = ComparePage(self.loader, self.thumbs)
        self.stack = QStackedWidget()
        self.stack.addWidget(gal)
        self.stack.addWidget(self.viewer)
        self.stack.addWidget(self.compare)
        self.quickbar = QWidget()
        self.quick_layout = QHBoxLayout(self.quickbar)
        self.quick_layout.setContentsMargins(8, 4, 8, 4)
        self.quick_layout.setSpacing(6)
        self.quick_buttons = {}
        container = QWidget()
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        cl.addWidget(self.stack, 1)
        cl.addWidget(self.quickbar)
        self.setCentralWidget(container)
        self.viewer.rowShown.connect(lambda *_: self._refresh_quicktags())
        self.compare.changed.connect(self._refresh_quicktags)
        self.view.selectionModel().selectionChanged.connect(lambda *_: self._refresh_quicktags())

        # status bar
        self.status_label = QLabel()
        self.progress_label = QLabel()
        self.progress = QProgressBar()
        self.progress.setFixedWidth(160)
        self.progress.hide()
        sb = self.statusBar()
        sb.addWidget(self.status_label, 1)
        sb.addPermanentWidget(self.progress_label)
        sb.addPermanentWidget(self.progress)

        self._rebuild_quickbar()
        self.slide_timer = QTimer(self)
        self.slide_timer.timeout.connect(self._slide_tick)
        self.setAcceptDrops(True)
        QApplication.instance().installEventFilter(self)

    def _act(self, text, shortcut, slot, menu=None, checkable=False, checked=False):
        a = QAction(text, self)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
            a.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        if checkable:
            a.setCheckable(True)
            a.setChecked(checked)
            a.toggled.connect(slot)
        else:
            a.triggered.connect(lambda *_: slot())
        self.addAction(a)
        if menu is not None:
            menu.addAction(a)
        return a

    def _build_actions(self):
        mb = self.menuBar()
        m = mb.addMenu("ไฟล์")
        self._act("เพิ่มโฟลเดอร์เข้าคลัง…", "Ctrl+O", self.add_folder_dialog, m)
        self._act("สแกนใหม่ทั้งหมด", "F5", self.rescan_all, m)
        m.addSeparator()
        self._act("ส่งออก…", "Ctrl+E", self.export_dialog, m)
        self._act("ย้ายไปโฟลเดอร์…", "", lambda: self.transfer_dialog(True), m)
        self._act("คัดลอกไปโฟลเดอร์…", "", lambda: self.transfer_dialog(False), m)
        self._act("เขียน .xmp (ดาว/ธง) ข้างไฟล์ที่เลือก", "", self.write_xmp_selected, m)
        m.addSeparator()
        self._act("นำเข้าข้อมูลจาก Photos Viewer 4/5…", "", self.import_old, m)
        self._act("ออก", "Ctrl+Q", self.close, m)

        m = mb.addMenu("คัดรูป")
        for n in range(6):
            self._act("ล้างดาว" if n == 0 else f"ให้ {n} ดาว", str(n), lambda n=n: self.apply_cull(rating=n), m)
        self._act("Pick (สลับ)", "P", lambda: self.apply_cull(flag=1), m)
        self._act("Reject (สลับ)", "X", lambda: self.apply_cull(flag=-1), m)
        self._act("ล้างธง", "U", lambda: self.apply_cull(flag=0, force=True), m)
        m.addSeparator()
        self._act("ย้อนกลับ", "Ctrl+Z", self.undo, m)
        self._act("ทำซ้ำ", "Ctrl+Y", self.redo, m)
        m.addSeparator()
        self._act("ไปรูปถัดไปหลังให้ดาว/ธง", "", self._set_auto_adv, m, True, self.auto_advance)
        self._act("เทียบรูปที่เลือก", "C", self.compare_selected, m)
        self._act("ลบที่เลือก (ถังขยะ)", "Delete", lambda: self.delete_ids(self.target_ids()), m)
        self._act("ลบทุกรูปที่ Reject…", "Ctrl+Shift+Delete", self.delete_rejected, m)

        m = mb.addMenu("แก้ไข")
        self._act("เลือกทั้งหมด", "Ctrl+A", lambda: self.view.selectAll(), m)
        self._act("แก้แท็ก…", "Ctrl+T", self.edit_tags, m)
        self._act("ลบแท็กออกจากรูปที่เลือก…", "Ctrl+Shift+T", self.remove_tags_dialog, m)
        self._act("แก้ไขแท็กด่วน…", "", self.edit_quick_tags, m)
        for n in range(1, 10):
            self._act(f"สลับแท็กด่วนที่ {n}", f"Ctrl+{n}", lambda n=n: self.quick_tag_index(n - 1))
        self._act("อ่านแท็กจากไฟล์ใหม่ทั้งหมด", "", self.reread_file_tags, m)
        self._act("เพิ่มลงอัลบั้ม…", "Ctrl+B", self.add_to_album_dialog, m)
        self._act("แสดงใน Explorer", "E", self.reveal_current, m)
        self._act("คัดลอกพาธ", "Ctrl+Shift+C", self.copy_path, m)

        m = mb.addMenu("เครื่องมือ")
        self._act("หารูปซ้ำ/คล้ายกัน (ในมุมมองนี้)…", "", self.find_duplicates, m)
        self._act("หารูปที่คล้ายรูปที่เลือก", "", self.find_similar, m)
        self._act("สแกนใบหน้า / จัดกลุ่มคน…", "", self.scan_faces, m)
        self._act("ติดแท็กชื่อคนให้รูปที่มีคนนั้น (ทุกคนที่ตั้งชื่อแล้ว)", "", self.tag_all_people, m)
        m.addSeparator()
        self._act("ล้างแคชภาพย่อ", "", self.clear_thumb_cache, m)

        m = mb.addMenu("มุมมอง")
        self._act("ธีมมืด", "", self._set_dark, m, True, self.dark)
        self._act("เต็มหน้าจอ", "F11", self.toggle_fullscreen, m)
        m = mb.addMenu("ช่วยเหลือ")
        self._act("ปุ่มลัด", "F1", lambda: ShortcutsDialog(self).exec(), m)
        self._act("เกี่ยวกับ", "", lambda: QMessageBox.information(self, APP_NAME, f"{APP_NAME}  เวอร์ชัน {__version__}\nข้อมูล: {self.data_dir}"), m)

    # ================================================================== settings / theme
    def _restore(self):
        g = self.settings.value("geometry")
        if g:
            self.restoreGeometry(g)
        self.slider.setValue(int(self.settings.value("cell", 170)))
        self.cb_sort.setCurrentIndex(max(0, self.cb_sort.findData(self.settings.value("sort", "taken_new"))))
        self.chk_rec.setChecked(self.settings.value("recursive", True, bool))
        self.chk_names.setChecked(self.settings.value("names", False, bool))
        self.delegate.cell = self.slider.value()
        self.delegate.show_names = self.chk_names.isChecked()
        self.chk_tags.setChecked(self.settings.value("show_tags", False, bool))
        self.delegate.show_tags = self.chk_tags.isChecked()

    def _apply_theme(self):
        QApplication.instance().setStyleSheet(theme.DARK if self.dark else theme.LIGHT)
        self.delegate.dark = self.dark
        self.viewer.set_dark(self.dark)
        self.view.viewport().update()

    def _set_dark(self, on):
        self.dark = bool(on)
        self.settings.setValue("dark", self.dark)
        self._apply_theme()

    def _set_auto_adv(self, on):
        self.auto_advance = bool(on)
        self.settings.setValue("auto_advance", self.auto_advance)

    def _cell_changed(self, v):
        self.delegate.cell = v
        self.delegate.sizeHintChanged.emit(self.model.index(0)) if self.model.rowCount() else None
        self.view.setIconSize(QSize(v, v))
        self.view.doItemsLayout()
        self._vis_timer.start(60)

    def _names_toggled(self, on):
        self.delegate.show_names = self.chk_names.isChecked()
        self.delegate.show_tags = self.chk_tags.isChecked()
        self.view.doItemsLayout()
        self.view.viewport().update()

    def closeEvent(self, e):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("roots", self.roots)
        self.settings.setValue("cell", self.slider.value())
        self.settings.setValue("sort", self.cb_sort.currentData())
        self.settings.setValue("recursive", self.chk_rec.isChecked())
        self.settings.setValue("names", self.chk_names.isChecked())
        self.settings.setValue("show_tags", self.chk_tags.isChecked())
        self.viewer.stop()
        for t in self.tasks:
            t.cancel()
        for t in list(self.tasks):
            t.wait(3000)
        self.thumbs.stop()
        self.loader.stop()
        QApplication.instance().removeEventFilter(self)
        super().closeEvent(e)

    # ================================================================== data / filters
    def current_filter(self) -> Filter:
        f = Filter(text=self.search.text().strip(), min_rating=self.cb_rating.currentData() or 0,
                   flag=self.cb_flag.currentData(), kind=self.cb_kind.currentData(),
                   sort=self.cb_sort.currentData(), recursive=self.chk_rec.isChecked(),
                   untagged=self.chk_untagged.isChecked())
        s = self.scope
        if s[0] == "folder":
            f.folder = s[1]
        elif s[0] == "album":
            f.album = s[1]
        elif s[0] == "month":
            f.month = s[1]
        elif s[0] == "tag":
            f.tag = s[1]
        elif s[0] == "place":
            f.place = s[1]
        elif s[0] == "person":
            f.person = s[1]
        if self.collection:
            f.use_ids, f.ids = True, self.collection["ids"]
        return f

    def _filters_changed(self, *_):
        if self.collection:
            self.close_collection(reload=False)
        self.reload()

    def _set_scope(self, scope):
        self.scope = scope
        if self.collection:
            self.close_collection(reload=False)
        self.reload(keep=False)

    def reload(self, keep=True):
        keep_ids = self.selected_ids() if keep else []
        cur = self.view.currentIndex().data(IdRole) if keep and self.view.currentIndex().isValid() else None
        rows = self.lib.query(self.current_filter())
        self.model.tags = self.lib.tags_map()
        self.model.set_rows(rows, self.collection["group"] if self.collection else None)
        self._info_cache.clear()
        if keep_ids:
            sm = self.view.selectionModel()
            from PyQt6.QtCore import QItemSelectionModel
            for i in keep_ids:
                r = self.model.row_of(i)
                if r >= 0:
                    sm.select(self.model.index(r), QItemSelectionModel.SelectionFlag.Select)
            if cur is not None and self.model.row_of(cur) >= 0:
                self.view.setCurrentIndex(self.model.index(self.model.row_of(cur)))
        self._after_reload()

    def _after_reload(self):
        empty = self.model.rowCount() == 0
        self.view.setVisible(not empty)
        self.empty.setVisible(empty)
        if empty:
            if not self.roots:
                self.empty.setText("ยังไม่มีรูปในคลัง\n\nกด Ctrl+O หรือลากโฟลเดอร์มาวางที่หน้าต่างนี้")
            elif self.index_task and self.index_task.isRunning():
                self.empty.setText("กำลังสแกนโฟลเดอร์…")
            else:
                self.empty.setText("ไม่พบรูปตามเงื่อนไขที่เลือก")
        if self.collection:
            self.banner.show()
            self.banner_label.setText(self.collection["title"])
            self.btn_keepbest.setVisible(self.collection.get("kind") in ("dup",))
        else:
            self.banner.hide()
        self._update_status()

    def _update_status(self):
        n = self.model.rowCount()
        sel = len(self.view.selectionModel().selectedIndexes()) if self.mode == PAGE_GALLERY else 0
        picks = sum(1 for r in self.model.rows if r[4] > 0)
        rej = sum(1 for r in self.model.rows if r[4] < 0)
        self.status_label.setText(f"{n:,} ไฟล์   ·   เลือก {sel}   ·   ✓ Pick {picks}   ·   ✕ Reject {rej}")

    def info_of(self, iid: int):
        d = self._info_cache.get(iid)
        if d is None:
            d = self.lib.info(iid) or {}
            if len(self._info_cache) > 2000:
                self._info_cache.clear()
            self._info_cache[iid] = d
        return d

    # ---- thumbnails visible-range
    def _request_visible(self):
        n = self.model.rowCount()
        if not n:
            return
        v = self.view
        vp = v.viewport().rect()
        a = v.indexAt(vp.topLeft() + vp.center() * 0)
        b = v.indexAt(vp.bottomRight())
        first = a.row() if a.isValid() else 0
        last = b.row() if b.isValid() else min(n - 1, first + 200)
        span = max(1, last - first + 1)
        lo, hi = max(0, first - span // 2), min(n, last + span + 1)
        order = list(range(first, min(n, last + 1))) + list(range(last + 1, hi)) + list(range(first - 1, lo - 1, -1))
        items = []
        for r in order:
            d = self.model.rows[r]
            items.append((d[0], d[1], d[2]))
        self.thumbs.want(items)

    def _thumb_done(self, iid):
        pass

    # ================================================================== selection helpers
    def selected_ids(self) -> list[int]:
        rows = sorted(i.row() for i in self.view.selectionModel().selectedIndexes())
        return [self.model.rows[r][0] for r in rows]

    def current_row_id(self):
        if self.mode == PAGE_VIEWER:
            return self.model.id_at(self.viewer.row)
        i = self.view.currentIndex()
        return self.model.id_at(i.row()) if i.isValid() else None

    def target_ids(self) -> list[int]:
        if self.mode == PAGE_VIEWER:
            i = self.model.id_at(self.viewer.row)
            return [i] if i is not None else []
        if self.mode == PAGE_COMPARE:
            p = self.compare.active
            return [p.row_id] if p else []
        ids = self.selected_ids()
        if not ids:
            i = self.current_row_id()
            ids = [i] if i is not None else []
        return ids

    def id_path(self, iid):
        r = self.model.row_of(iid)
        return self.model.path_at(r) if r >= 0 else (self.info_of(iid) or {}).get("disp")

    # ================================================================== background tasks
    def run_task(self, fn, on_done=None, on_progress=None, label=""):
        t = Task(fn, self)
        self.tasks.append(t)
        self._busy = getattr(self, "_busy", 0) + 1
        self.progress_label.setText(label)
        self.progress.setRange(0, 0)
        self.progress.show()

        def prog(v):
            if isinstance(v, tuple) and len(v) == 2 and all(isinstance(x, int) for x in v) and v[1] > 0:
                self.progress.setRange(0, v[1])
                self.progress.setValue(v[0])
            if on_progress:
                on_progress(v)

        def fin():
            if t in self.tasks:
                self.tasks.remove(t)
            self._busy = max(0, self._busy - 1)
            if not self._busy:
                self.progress.hide()
                self.progress_label.setText("")
            t.deleteLater()

        t.progress.connect(prog)
        if on_done:
            t.done.connect(on_done)
        t.failed.connect(self._task_failed)
        t.finished.connect(fin)
        t.start()
        return t

    def _task_failed(self, tb: str):
        try:
            with open(os.path.join(self.data_dir, "error.log"), "a", encoding="utf-8") as fh:
                fh.write(tb + "\n")
        except OSError:
            pass
        self.statusBar().showMessage("เกิดข้อผิดพลาด: " + tb.strip().splitlines()[-1], 10000)

    # ---- indexing
    def _startup_scan(self):
        self._pending_roots = [r for r in self.roots]
        self._next_index()

    def rescan_all(self):
        self._pending_roots = [r for r in self.roots if r not in self._pending_roots]
        if not self.index_task:
            self._next_index()

    def add_folder_dialog(self):
        d = QFileDialog.getExistingDirectory(self, "เลือกโฟลเดอร์รูป/วิดีโอ", self.roots[-1] if self.roots else "")
        if d:
            self.add_root(d)

    def add_root(self, folder: str):
        folder = os.path.abspath(folder)
        key = canon(folder).rstrip("\\/") + os.sep
        for r in self.roots:
            if key.startswith(canon(r).rstrip("\\/") + os.sep):
                break                      # already covered by an existing root
        else:
            self.roots = [r for r in self.roots if not (canon(r).rstrip("\\/") + os.sep).startswith(key)]
            self.roots.append(folder)
            self.settings.setValue("roots", self.roots)
        self._pending_roots.append(folder)
        self.scope = ("all",)
        if not self.index_task:
            self._next_index()

    def _next_index(self):
        if not self._pending_roots:
            self._begin_meta()
            return
        folder = self._pending_roots.pop(0)
        if not os.path.isdir(folder):
            self.statusBar().showMessage(f"ไม่พบโฟลเดอร์ {folder} (ไดรฟ์อาจไม่ได้เสียบ) – ข้อมูลเดิมยังอยู่", 6000)
            self._next_index()
            return

        def fn(task):
            return self.lib.index_folder(folder, lambda n: task.progress.emit(("scan", n)), task.is_cancelled)

        def prog(v):
            if v and v[0] == "scan":
                self.progress_label.setText(f"สแกน {os.path.basename(folder) or folder}: {v[1]:,} ไฟล์")

        def done(res):
            self.index_task = None
            if res.get("warning"):
                self.statusBar().showMessage(res["warning"], 8000)
            elif res.get("added") or res.get("removed"):
                self.statusBar().showMessage(f"สแกนเสร็จ: เพิ่ม {res['added']:,} · ลบ {res['removed']:,}", 5000)
            self.refresh_sidebar()
            if self.mode == PAGE_GALLERY:
                self.reload()
            self._next_index()

        def failed(_):
            self.index_task = None
            self._next_index()

        self.index_task = self.run_task(fn, done, prog, "กำลังสแกน…")
        self.index_task.failed.connect(failed)
        self._after_reload()

    def _begin_meta(self):
        if self.meta_task or (self.lib.count_pending_meta() == 0 and self.lib.count_pending_tags() == 0):
            return

        def fn(task):
            total, done = self.lib.count_pending_meta(), 0
            with ThreadPoolExecutor(4) as ex:
                while not task.is_cancelled():
                    rows = self.lib.pending_meta(240)
                    if not rows:
                        break
                    res = list(ex.map(lambda r: (r["id"], media.read_meta(r["disp"], r["kind"])), rows))
                    self.lib.save_meta(res)
                    done += len(rows)
                    task.progress.emit((done, max(total, done)))
            # keywords already stored inside the files (Explorer "Tags", XMP, IPTC)
            ttotal, tdone = self.lib.count_pending_tags(), 0
            with winprops.TagSession() as sess:
                while not task.is_cancelled():
                    rows = self.lib.pending_tag_scan(300)
                    if not rows:
                        break
                    out = []
                    for r in rows:
                        tags = []
                        if sess.ok:
                            try:
                                tags = sess.read(r["disp"])
                            except Exception:
                                tags = []
                        tags = split_tags(tags + media.embedded_tags(r["disp"]))
                        out.append((r["id"], tags))
                    self.lib.save_embedded_tags(out)
                    tdone += len(rows)
                    task.progress.emit((tdone, max(ttotal, tdone)))
            return done

        def finish(_):
            self.meta_task = None
            self.refresh_sidebar()
            if self.mode == PAGE_GALLERY and not self.collection:
                self.reload()

        self.meta_task = self.run_task(fn, finish, None, "อ่านข้อมูล/แท็กจากไฟล์…")
        self.meta_task.failed.connect(lambda _: setattr(self, "meta_task", None))

    def reread_file_tags(self):
        self.lib.reset_tag_scan()
        self._begin_meta()

    # ================================================================== sidebar
    def refresh_sidebar(self):
        # folders
        tree = self.tree_folders
        expanded = set()
        for i in range(tree.topLevelItemCount()):
            self._collect_expanded(tree.topLevelItem(i), expanded)
        tree.clear()
        stats = self.lib.stats()
        all_item = QTreeWidgetItem([f"ทั้งหมด  ({stats['total']:,})"])
        all_item.setData(0, UR, None)
        tree.addTopLevelItem(all_item)
        for root in self.roots:
            ra = os.path.abspath(root)
            ritem = self._mk_folder_item(os.path.basename(ra.rstrip("\\/")) or ra, ra)
            ritem.setData(0, UR + 1, 0)
            tree.addTopLevelItem(ritem)
            nodes = {ra: ritem}
            for dirkey, n, d in self.lib.folder_counts(ra):
                real = os.path.dirname(d)
                rel = os.path.relpath(real, ra)
                parts = [] if rel == "." else rel.split(os.sep)
                chain = [ritem]
                cur, path = ritem, ra
                for part in parts:
                    path = os.path.join(path, part)
                    child = nodes.get(path)
                    if child is None:
                        child = self._mk_folder_item(part, path)
                        child.setData(0, UR + 1, 0)
                        cur.addChild(child)
                        nodes[path] = child
                    cur = child
                    chain.append(child)
                for node in chain:
                    node.setData(0, UR + 1, node.data(0, UR + 1) + n)
            for path, node in nodes.items():
                node.setText(0, f"{node.data(0, UR + 2)}  ({node.data(0, UR + 1):,})")
                if path in expanded or path == ra:
                    node.setExpanded(True)
            ritem.sortChildren(0, Qt.SortOrder.AscendingOrder)
        # dates
        self.tree_dates.clear()
        years: dict[str, QTreeWidgetItem] = {}
        for ym, n in self.lib.month_counts():
            y = ym[:4]
            if y not in years:
                yi = QTreeWidgetItem([y])
                yi.setData(0, UR, y)
                self.tree_dates.addTopLevelItem(yi)
                years[y] = yi
                yi.setData(0, UR + 1, 0)
            mi = QTreeWidgetItem([f"{ym}  ({n:,})"])
            mi.setData(0, UR, ym)
            years[y].addChild(mi)
            years[y].setData(0, UR + 1, years[y].data(0, UR + 1) + n)
        for y, yi in years.items():
            yi.setText(0, f"{y}  ({yi.data(0, UR + 1):,})")
        # albums / places / tags / people
        self.list_albums.clear()
        for aid, name, n in self.lib.albums():
            it2 = QListWidgetItem(f"{name}  ({n})")
            it2.setData(UR, aid)
            self.list_albums.addItem(it2)
        self.list_places.clear()
        for la, lo, n in self.lib.place_counts():
            it2 = QListWidgetItem(f"{abs(la):.1f}°{'N' if la >= 0 else 'S'}  {abs(lo):.1f}°{'E' if lo >= 0 else 'W'}  ({n})")
            it2.setData(UR, (la, lo))
            self.list_places.addItem(it2)
        self.refresh_tag_list()
        self.refresh_people()

    def _mk_folder_item(self, name, path):
        it = QTreeWidgetItem([name])
        it.setData(0, UR, path)
        it.setData(0, UR + 2, name)
        return it

    def _collect_expanded(self, item, out):
        if item.isExpanded() and item.data(0, UR):
            out.add(item.data(0, UR))
        for i in range(item.childCount()):
            self._collect_expanded(item.child(i), out)

    def _folder_clicked(self, item, _col=0):
        p = item.data(0, UR)
        self._set_scope(("folder", p) if p else ("all",))

    def _folder_menu(self, pos):
        item = self.tree_folders.itemAt(pos)
        if not item or not item.data(0, UR):
            return
        path = item.data(0, UR)
        m = QMenu(self)
        m.addAction("แสดงใน Explorer", lambda: reveal_in_explorer(os.path.join(path, ".")) if False else open_default(path))
        if path in self.roots or os.path.abspath(path) in [os.path.abspath(r) for r in self.roots]:
            m.addAction("สแกนโฟลเดอร์นี้ใหม่", lambda: (self._pending_roots.append(path), None if self.index_task else self._next_index()))
            m.addAction("นำออกจากคลัง (ไม่ลบไฟล์จริง)", lambda: self.remove_root(path))
        m.exec(self.tree_folders.viewport().mapToGlobal(pos))

    def remove_root(self, path):
        if QMessageBox.question(self, "นำออกจากคลัง", f"นำ “{path}” ออกจากคลัง?\n(ไฟล์จริงไม่ถูกลบ; ดาว/แท็กของรูปในโฟลเดอร์นี้จะหายไป)") \
                != QMessageBox.StandardButton.Yes:
            return
        self.roots = [r for r in self.roots if os.path.abspath(r) != os.path.abspath(path)]
        self.settings.setValue("roots", self.roots)
        self.lib.remove_scope(path)
        self.scope = ("all",)
        self.refresh_sidebar()
        self.reload(keep=False)

    # ---- albums
    def _album_menu(self, pos):
        item = self.list_albums.itemAt(pos)
        m = QMenu(self)
        m.addAction("อัลบั้มใหม่…", self.new_album)
        if item:
            aid = item.data(UR)
            m.addAction("เปลี่ยนชื่อ…", lambda: self.rename_album(aid))
            m.addAction("ลบอัลบั้ม (ไม่ลบรูป)", lambda: (self.lib.delete_album(aid), self.refresh_sidebar()))
        m.exec(self.list_albums.viewport().mapToGlobal(pos))

    def new_album(self):
        name, ok = QInputDialog.getText(self, "อัลบั้มใหม่", "ชื่ออัลบั้ม:")
        if ok and name.strip():
            aid = self.lib.create_album(name)
            self.refresh_sidebar()
            return aid

    def rename_album(self, aid):
        name, ok = QInputDialog.getText(self, "เปลี่ยนชื่อ", "ชื่อใหม่:")
        if ok and name.strip():
            self.lib.rename_album(aid, name)
            self.refresh_sidebar()

    def add_to_album_dialog(self):
        ids = self.target_ids()
        if not ids:
            return
        albums = self.lib.albums()
        names = [a[1] for a in albums] + ["＋ สร้างอัลบั้มใหม่…"]
        name, ok = QInputDialog.getItem(self, "เพิ่มลงอัลบั้ม", f"{len(ids)} ไฟล์ →", names, 0, False)
        if not ok:
            return
        aid = self.new_album() if name == names[-1] else next(a[0] for a in albums if a[1] == name)
        if aid is not None:
            self.lib.album_add(aid, ids)
            self.refresh_sidebar()
            self.statusBar().showMessage(f"เพิ่ม {len(ids)} ไฟล์เข้าอัลบั้มแล้ว", 3000)

    def remove_from_album(self):
        if self.scope[0] == "album":
            self.lib.album_remove(self.scope[1], self.selected_ids())
            self.refresh_sidebar()
            self.reload(keep=False)

    # ================================================================== culling
    def apply_cull(self, rating=None, flag=None, force=False):
        ids = self.target_ids()
        if not ids:
            return
        old = self.lib.get_states(ids)
        if not old:
            return
        same = flag is not None and not force and all(old[i][1] == flag for i in old)
        new = {}
        for i, (r, f) in old.items():
            if rating is not None:
                r = rating
            if flag is not None:
                f = 0 if same else flag
            new[i] = (r, f)
        self._commit_states(old, new, push=True)
        if self.auto_advance and (flag is not None or rating):
            if self.mode == PAGE_VIEWER:
                self.step(1)
            elif self.mode == PAGE_GALLERY and len(ids) == 1:
                r = self.model.row_of(ids[0])
                if 0 <= r < self.model.rowCount() - 1:
                    nxt = self.model.index(r + 1)
                    self.view.setCurrentIndex(nxt)
                    self.view.scrollTo(nxt)

    def _commit_states(self, old, new, push):
        self.lib.set_states(new)
        for i, (r, f) in new.items():
            self.model.set_state(i, r, f)
        if push:
            self.undo_stack.append((old, new))
            del self.undo_stack[:-500]
            self.redo_stack.clear()
        if self.mode == PAGE_VIEWER:
            self.viewer.refresh_hud()
        elif self.mode == PAGE_COMPARE:
            self._refresh_compare_badges()
        self._update_status()

    def _refresh_compare_badges(self):
        st = self.lib.get_states([p.row_id for p in self.compare.panes])
        for p in self.compare.panes:
            p.canvas.rating, p.canvas.flag = st.get(p.row_id, (0, 0))
            p.canvas.update()

    def undo(self):
        if self.undo_stack:
            old, new = self.undo_stack.pop()
            self._commit_states(new, old, push=False)
            self.redo_stack.append((old, new))
            self.statusBar().showMessage("ย้อนกลับแล้ว", 1500)

    def redo(self):
        if self.redo_stack:
            old, new = self.redo_stack.pop()
            self._commit_states(old, new, push=False)
            self.undo_stack.append((old, new))

    # ================================================================== modes
    def _set_mode(self, mode):
        self.mode = mode
        chrome = mode == PAGE_GALLERY
        self.toolbar.setVisible(chrome)
        self.dock.setVisible(chrome)
        self.stack.setCurrentIndex(mode)
        self.slide_timer.stop()
        if mode != PAGE_VIEWER:
            self.viewer.stop()
        self._update_status()

    def enter_viewer(self, row: int):
        if not 0 <= row < self.model.rowCount():
            return
        self._set_mode(PAGE_VIEWER)
        self.viewer.show_row(row)
        self.viewer.setFocus()

    def show_viewer_row(self, row: int):
        if 0 <= row < self.model.rowCount():
            self.viewer.show_row(row)

    def step(self, d: int) -> bool:
        r = self.viewer.row + d
        if 0 <= r < self.model.rowCount():
            self.viewer.show_row(r)
            return True
        return False

    def leave_viewer(self):
        row = self.viewer.row
        self._set_mode(PAGE_GALLERY)
        if 0 <= row < self.model.rowCount():
            idx = self.model.index(row)
            self.view.clearSelection()
            self.view.setCurrentIndex(idx)
            self.view.selectionModel().select(idx, self.view.selectionModel().SelectionFlag.ClearAndSelect)
            self.view.scrollTo(idx, QAbstractItemView.ScrollHint.PositionAtCenter)
        self.view.setFocus()

    def compare_selected(self):
        if self.mode == PAGE_COMPARE:
            return
        ids = []
        if self.mode == PAGE_VIEWER:
            r = self.viewer.row
            ids = [self.model.id_at(r), self.model.id_at(r + 1)]
            if ids[1] is None:
                ids = [self.model.id_at(r - 1), ids[0]]
        else:
            ids = self.selected_ids()
            if len(ids) == 1:
                r = self.model.row_of(ids[0])
                nxt = self.model.id_at(r + 1)
                ids = [ids[0], nxt] if nxt is not None else ids
        ids = [i for i in ids if i is not None and self.model.rows[self.model.row_of(i)][2] == 0][:4]
        if len(ids) < 2:
            self.statusBar().showMessage("เลือกรูป 2–4 รูปก่อน (เฉพาะรูปภาพ) แล้วกด C", 4000)
            return
        infos = self.lib.infos_for(ids)
        items = []
        for i in ids:
            d = infos.get(i)
            if not d:
                continue
            bits = [f"{d['w']}×{d['h']}" if d.get("w") else "", human_size(d["size"]), d.get("camera") or "", d.get("taken") or ""]
            items.append({"id": i, "path": d["disp"], "w": d.get("w"), "h": d.get("h"), "rating": d["rating"],
                          "flag": d["flag"], "lines": [d["name"], "  ·  ".join(b for b in bits if b)]})
        self.prev_mode = self.mode
        self._set_mode(PAGE_COMPARE)
        self.compare.set_items(items)

    def leave_compare(self):
        ids = [p.row_id for p in self.compare.panes]
        back = self.prev_mode
        self._set_mode(back if back == PAGE_VIEWER and self.model.rowCount() else PAGE_GALLERY)
        if self.mode == PAGE_VIEWER:
            self.viewer.show_row(min(self.viewer.row, self.model.rowCount() - 1))
        else:
            self.view.clearSelection()
            from PyQt6.QtCore import QItemSelectionModel
            for i in ids:
                r = self.model.row_of(i)
                if r >= 0:
                    self.view.selectionModel().select(self.model.index(r), QItemSelectionModel.SelectionFlag.Select)
            self.view.setFocus()

    def toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def _slide_tick(self):
        if not self.step(1):
            self.slide_timer.stop()
            self.statusBar().showMessage("สไลด์โชว์จบแล้ว", 2000)

    # ================================================================== keyboard (viewer / compare)
    def eventFilter(self, obj, ev):
        if ev.type() != QEvent.Type.KeyPress or not self.isActiveWindow():
            return False
        fw = QApplication.focusWidget()
        if isinstance(fw, QLineEdit):
            return False
        mods = ev.modifiers()
        if mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
            return False
        k = ev.key()
        K = Qt.Key
        if self.mode == PAGE_VIEWER:
            c = self.viewer.canvas
            cur = QApplication.instance().primaryScreen() and c.mapFromGlobal(__import__("PyQt6.QtGui", fromlist=["QCursor"]).QCursor.pos())
            if k == K.Key_Space and self.viewer.stack.currentWidget() is self.viewer.video:
                self.viewer.video.toggle()
            elif k in (K.Key_Right, K.Key_Down, K.Key_Space, K.Key_PageDown):
                self.step(1)
            elif k in (K.Key_Left, K.Key_Up, K.Key_Backspace, K.Key_PageUp):
                self.step(-1)
            elif k == K.Key_Home:
                self.show_viewer_row(0)
            elif k == K.Key_End:
                self.show_viewer_row(self.model.rowCount() - 1)
            elif k == K.Key_Escape or k == K.Key_Return or k == K.Key_Enter:
                self.leave_viewer()
            elif k == K.Key_F:
                c.fit()
            elif k == K.Key_Z:
                c.toggle_100(cur if c.rect().contains(cur) else None)
            elif k in (K.Key_Plus, K.Key_Equal):
                c.zoom_at(1.25)
            elif k == K.Key_Minus:
                c.zoom_at(0.8)
            elif k == K.Key_I:
                c.show_hud = not c.show_hud
                c.update()
            elif k == K.Key_S:
                if self.slide_timer.isActive():
                    self.slide_timer.stop()
                else:
                    self.slide_timer.start(3000)
                self.statusBar().showMessage("สไลด์โชว์: " + ("เปิด" if self.slide_timer.isActive() else "ปิด"), 1500)
            else:
                return False
            return True
        if self.mode == PAGE_COMPARE:
            a = self.compare.active
            if k == K.Key_Escape:
                self.leave_compare()
            elif k in (K.Key_Right, K.Key_Down):
                self.compare.move_active(1)
            elif k in (K.Key_Left, K.Key_Up):
                self.compare.move_active(-1)
            elif k == K.Key_F:
                for p in self.compare.panes:
                    p.canvas.fit()
            elif k == K.Key_Z and a:
                a.canvas.toggle_100()
            elif k in (K.Key_Plus, K.Key_Equal) and a:
                a.canvas.zoom_at(1.25)
            elif k == K.Key_Minus and a:
                a.canvas.zoom_at(0.8)
            elif k == K.Key_L:
                self.compare.sync = not self.compare.sync
                self.statusBar().showMessage("ล็อกซูม: " + ("เปิด" if self.compare.sync else "ปิด"), 1500)
            else:
                return False
            return True
        if self.mode == PAGE_GALLERY:
            if k in (K.Key_Return, K.Key_Enter) and fw is self.view:
                i = self.view.currentIndex()
                if i.isValid():
                    self.enter_viewer(i.row())
                    return True
            elif k == K.Key_Escape:
                if self.collection:
                    self.close_collection()
                else:
                    self.view.clearSelection()
                return True
        return False

    # ================================================================== context menu
    def _gallery_menu(self, pos):
        if not self.model.rowCount():
            return
        m = QMenu(self)
        m.addAction("เปิดดู", lambda: self.enter_viewer(self.view.currentIndex().row()))
        m.addAction("เทียบรูปที่เลือก  (C)", self.compare_selected)
        m.addSeparator()
        m.addAction("Pick (P)", lambda: self.apply_cull(flag=1))
        m.addAction("Reject (X)", lambda: self.apply_cull(flag=-1))
        sub = m.addMenu("ให้ดาว")
        for n in range(6):
            sub.addAction("ล้างดาว" if n == 0 else "★" * n, lambda n=n: self.apply_cull(rating=n))
        m.addSeparator()
        m.addAction("แก้แท็ก…", self.edit_tags)
        m.addAction("ลบแท็ก…", self.remove_tags_dialog)
        m.addAction("เพิ่มลงอัลบั้ม…", self.add_to_album_dialog)
        if self.scope[0] == "album":
            m.addAction("เอาออกจากอัลบั้มนี้", self.remove_from_album)
        m.addAction("หารูปที่คล้ายรูปนี้", self.find_similar)
        m.addSeparator()
        m.addAction("ย้ายไปโฟลเดอร์…", lambda: self.transfer_dialog(True))
        m.addAction("คัดลอกไปโฟลเดอร์…", lambda: self.transfer_dialog(False))
        m.addAction("แสดงใน Explorer", self.reveal_current)
        m.addAction("คัดลอกพาธ", self.copy_path)
        m.addSeparator()
        m.addAction("ลบ (ถังขยะ)", lambda: self.delete_ids(self.target_ids()))
        m.exec(self.view.viewport().mapToGlobal(pos))

    def reveal_current(self):
        i = self.current_row_id() if self.mode != PAGE_COMPARE else (self.compare.active.row_id if self.compare.active else None)
        p = self.id_path(i) if i is not None else None
        if p:
            reveal_in_explorer(p)

    def copy_path(self):
        paths = [self.id_path(i) for i in self.target_ids()]
        QGuiApplication.clipboard().setText("\n".join(p for p in paths if p))
        self.statusBar().showMessage("คัดลอกพาธแล้ว", 1500)

    # ================================================================== drag & drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if os.path.isdir(p):
                self.add_root(p)
            elif os.path.isfile(p):
                self.add_root(os.path.dirname(p))

    # ================================================================== delete / move / copy
    def delete_ids(self, ids, confirm=True):
        ids = [i for i in ids if i is not None]
        if not ids:
            return
        pmap = {}
        for i in ids:
            p = self.id_path(i)
            if p:
                pmap[p] = i
        from .util import trash_available
        if confirm:
            txt = f"ย้าย {len(pmap):,} ไฟล์ไปที่ถังขยะ?"
            if not trash_available():
                txt = f"ลบถาวร {len(pmap):,} ไฟล์? (ไม่พบ send2trash จึงกู้คืนไม่ได้)"
            if QMessageBox.question(self, "ลบไฟล์", txt) != QMessageBox.StandardButton.Yes:
                return
        old_row = self.viewer.row

        def fn(task):
            return recycle(list(pmap.keys()))

        def done(res):
            ok, failed, _ = res
            gone = [pmap[p] for p in ok]
            self.lib.remove_ids(gone)
            self.model.remove_ids(gone)
            for i in gone:
                self.thumbs.forget(i)
                self.loader.forget(i)
                self._info_cache.pop(i, None)
            if self.mode == PAGE_COMPARE:
                for i in gone:
                    self.compare.remove_id(i)
                if len(self.compare.panes) < 1:
                    self.leave_compare()
            elif self.mode == PAGE_VIEWER:
                n = self.model.rowCount()
                if n == 0:
                    self.leave_viewer()
                else:
                    self.viewer.show_row(min(old_row, n - 1))
            self._after_reload()
            self.refresh_sidebar()
            msg = f"ย้ายไปถังขยะแล้ว {len(ok):,} ไฟล์"
            if failed:
                msg += f" · ล้มเหลว {len(failed)}: {failed[0][1]}"
            self.statusBar().showMessage(msg, 6000)

        self.run_task(fn, done, None, "กำลังลบ…")

    def delete_rejected(self):
        rows = self.lib.query(Filter(flag="reject"))
        if not rows:
            self.statusBar().showMessage("ไม่มีรูปที่ถูก Reject", 3000)
            return
        infos = self.lib.infos_for([r[0] for r in rows])
        total = sum(d["size"] for d in infos.values())
        if QMessageBox.question(self, "ลบรูปที่ Reject",
                                f"ย้าย {len(rows):,} ไฟล์ที่ถูก Reject ({human_size(total)}) ไปที่ถังขยะ?") \
                == QMessageBox.StandardButton.Yes:
            # ids not in current model are resolved through the DB
            self._info_cache.update(infos)
            self.delete_ids([r[0] for r in rows], confirm=False)

    def transfer_dialog(self, move: bool):
        ids = self.target_ids()
        if not ids:
            return
        dest = QFileDialog.getExistingDirectory(self, "ย้ายไปที่…" if move else "คัดลอกไปที่…")
        if not dest:
            return
        items = [(i, self.id_path(i)) for i in ids if self.id_path(i)]

        def fn(task):
            return tools.transfer_files(items, dest, move, task)

        def done(res):
            ok, failed = res
            if move:
                for iid, _src, dst in ok:
                    self.lib.relocate(iid, dst)
            inside = any(canon(dest).startswith(canon(r)) for r in self.roots)
            if not inside and ok:
                self.add_root(dest)
            elif ok:
                self._pending_roots.append(dest)
                if not self.index_task:
                    self._next_index()
            self.reload()
            msg = f"{'ย้าย' if move else 'คัดลอก'}แล้ว {len(ok):,} ไฟล์"
            if failed:
                msg += f" · ล้มเหลว {len(failed)}: {failed[0][1]}"
            self.statusBar().showMessage(msg, 6000)

        self.run_task(fn, done, None, "กำลังย้าย…" if move else "กำลังคัดลอก…")

    # ================================================================== tags
    def edit_tags(self):
        ids = self.target_ids()
        if not ids:
            return
        known = self.lib.tag_counts()
        if len(ids) == 1:
            cur = ", ".join(split_tags((self.lib.info(ids[0]) or {}).get("tags", "")))
            dlg = TagEditDialog(self, known, cur, "แก้แท็ก", "แท็ก (คั่นด้วยจุลภาค – พิมพ์แล้วเลือกจากรายการได้):")
            if not dlg.exec():
                return
            self.lib.set_tags(ids[0], dlg.tags())
        else:
            dlg = TagEditDialog(self, known, "", "เพิ่มแท็ก", f"เพิ่มแท็กให้ {len(ids)} ไฟล์ (คั่นด้วยจุลภาค):")
            if not dlg.exec() or not dlg.tags():
                return
            self.lib.add_tags(ids, dlg.tags())
        self._after_tag_change(ids)

    def _after_tag_change(self, ids):
        """Refresh the views of the tags and push them into the files (Explorer keywords) where possible."""
        self._info_cache.clear()
        self.model.tags = self.lib.tags_map()
        self.view.viewport().update()
        self.refresh_tag_list()
        self._refresh_quicktags()
        if self.mode == PAGE_GALLERY and (self.chk_untagged.isChecked() or self.scope[0] == "tag"):
            if self.scope[0] == "tag" and not self.lib.ids_with_tag(self.scope[1]):
                self.scope = ("all",)
            row = self.view.currentIndex().row()
            self.reload(keep=False)
            if row >= 0 and self.model.rowCount():
                self.view.setCurrentIndex(self.model.index(min(row, self.model.rowCount() - 1)))
        self._write_explorer_tags(ids)

    def refresh_tag_list(self):
        self.list_tags.clear()
        for tag, n in self.lib.tag_counts():
            it = QListWidgetItem(("📌 " if tag in self.quick_tags else "") + f"{tag}  ({n})")
            it.setData(UR, tag)
            self.list_tags.addItem(it)

    # ---- quick tags
    def _rebuild_quickbar(self):
        while self.quick_layout.count():
            w = self.quick_layout.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.quick_buttons = {}
        self.quick_layout.addWidget(QLabel("แท็กด่วน:"))
        if not self.quick_tags:
            hint = QLabel("ยังไม่มี – กด ⚙ หรือคลิกขวาที่แท็กในไซด์บาร์ → ปักเป็นแท็กด่วน")
            hint.setEnabled(False)
            self.quick_layout.addWidget(hint)
        for i, tag in enumerate(self.quick_tags[:12]):
            b = QPushButton(tag + (f"  [{i + 1}]" if i < 9 else ""))
            b.setCheckable(True)
            b.setProperty("base", b.text())
            b.setToolTip("คลิกเพื่อติด/เอาแท็กนี้ออกจากรูปที่เลือก" + (f"  (Ctrl+{i + 1})" if i < 9 else ""))
            b.clicked.connect(lambda _=False, t=tag: self.quick_tag(t))
            self.quick_layout.addWidget(b)
            self.quick_buttons[tag] = b
        self.quick_layout.addStretch(1)
        gear = QPushButton("⚙")
        gear.setToolTip("แก้ไขแท็กด่วน")
        gear.setFixedWidth(34)
        gear.clicked.connect(self.edit_quick_tags)
        self.quick_layout.addWidget(gear)
        self._refresh_quicktags()

    def _refresh_quicktags(self):
        if not self.quick_buttons:
            return
        ids = self.target_ids() if (self.model.rowCount() or self.mode != PAGE_GALLERY) else []
        for tag, b in self.quick_buttons.items():
            k = tag.casefold()
            have = sum(1 for i in ids if k in {t.casefold() for t in split_tags(self.model.tags.get(i, ""))})
            partial = 0 < have < len(ids)
            b.blockSignals(True)
            b.setChecked(bool(ids) and have == len(ids))
            b.setText(("◐ " if partial else "") + b.property("base"))
            b.blockSignals(False)

    def edit_quick_tags(self):
        dlg = TagEditDialog(self, self.lib.tag_counts(), ", ".join(self.quick_tags), "แท็กด่วน",
                            "แท็กที่ต้องการให้กดติดได้ทันที (สูงสุด 12 อัน; 9 อันแรกใช้ Ctrl+1…9):")
        if dlg.exec():
            self.quick_tags = dlg.tags()[:12]
            self.settings.setValue("quick_tags", self.quick_tags)
            self._rebuild_quickbar()
            self.refresh_tag_list()

    def toggle_quick_pin(self, tag):
        if tag in self.quick_tags:
            self.quick_tags.remove(tag)
        elif len(self.quick_tags) < 12:
            self.quick_tags.append(tag)
        else:
            self.statusBar().showMessage("แท็กด่วนเต็ม 12 อันแล้ว", 3000)
            return
        self.settings.setValue("quick_tags", self.quick_tags)
        self._rebuild_quickbar()
        self.refresh_tag_list()

    def quick_tag_index(self, i):
        if i < len(self.quick_tags):
            self.quick_tag(self.quick_tags[i])

    def quick_tag(self, tag):
        ids = self.target_ids()
        if not ids:
            return
        k = tag.casefold()
        have = [i for i in ids if k in {t.casefold() for t in split_tags(self.model.tags.get(i, ""))}]
        if len(have) == len(ids):
            changed = self.lib.remove_tags(ids, [tag])
            msg = f"เอาแท็ก “{tag}” ออกจาก {len(changed)} รูป"
        else:
            self.lib.add_tags(ids, [tag])
            changed = ids
            msg = f"ติดแท็ก “{tag}” ให้ {len(ids)} รูป"
        self.statusBar().showMessage(msg, 2500)
        advance_row = None
        if self.auto_advance and len(have) != len(ids) and len(ids) == 1:
            if self.mode == PAGE_VIEWER:
                advance_row = self.viewer.row + 1
            elif self.mode == PAGE_GALLERY and not self.chk_untagged.isChecked():
                advance_row = self.model.row_of(ids[0]) + 1
        self._after_tag_change(changed)
        if advance_row is not None and 0 <= advance_row < self.model.rowCount():
            if self.mode == PAGE_VIEWER:
                self.viewer.show_row(advance_row)
            else:
                idx = self.model.index(advance_row)
                self.view.setCurrentIndex(idx)
                self.view.scrollTo(idx)

    # ---- people -> tags
    def tag_all_people(self):
        from . import faces
        n, ids = faces.tag_named(self.lib)
        if not n:
            self.statusBar().showMessage("ยังไม่มีคนที่ตั้งชื่อ – สแกนใบหน้าแล้วตั้งชื่อในแท็บ คน ก่อน", 5000)
            return
        self.statusBar().showMessage(f"ติดแท็กชื่อ {n} คน ให้ {len(ids):,} รูปแล้ว", 6000)
        self._after_tag_change(ids)

    def _write_explorer_tags(self, ids):
        if not winprops.available() or not ids:
            return
        infos = self.lib.infos_for(ids)
        work = [(d["disp"], split_tags(d["tags"])) for d in infos.values()
                if os.path.splitext(d["disp"])[1].lower() in winprops.TAGGABLE]
        if not work:
            return

        def fn(task):
            bad = 0
            with winprops.TagSession() as s:
                for p, tags in work:
                    try:
                        s.write(p, tags)
                    except Exception:
                        bad += 1
            return bad

        self.run_task(fn, lambda bad: self.statusBar().showMessage(
            "เขียนแท็กลง Explorer แล้ว" + (f" (ล้มเหลว {bad})" if bad else ""), 4000), None, "เขียนแท็ก…")

    # ---- remove tags (several tags x several images)
    def remove_tags_dialog(self):
        ids = self.target_ids()
        if not ids:
            return
        tags = self.lib.tags_of(ids)
        if not tags:
            self.statusBar().showMessage("รูปที่เลือกยังไม่มีแท็ก", 3000)
            return
        dlg = TagRemoveDialog(self, tags, len(ids))
        if not dlg.exec():
            return
        chosen = dlg.chosen()
        if not chosen:
            return
        changed = self.lib.remove_tags(ids, chosen)
        self.statusBar().showMessage(f"ลบแท็ก {len(chosen)} รายการ จาก {len(changed):,} รูปแล้ว", 5000)
        self._after_tag_change(changed)

    # ---- sidebar tag menu: rename / merge / delete everywhere
    def _tag_menu(self, pos):
        item = self.list_tags.itemAt(pos)
        if not item:
            return
        tag = item.data(UR)
        m = QMenu(self)
        m.addAction("เลิกปักแท็กด่วน" if tag in self.quick_tags else "ปักเป็นแท็กด่วน", lambda: self.toggle_quick_pin(tag))
        m.addAction("เปลี่ยนชื่อ / รวมกับแท็กอื่น…", lambda: self.rename_tag_everywhere(tag))
        m.addAction("ลบแท็กนี้ออกจากทุกรูป…", lambda: self.delete_tag_everywhere(tag))
        m.exec(self.list_tags.viewport().mapToGlobal(pos))

    def rename_tag_everywhere(self, tag):
        new, ok = QInputDialog.getText(self, "เปลี่ยนชื่อแท็ก",
                                       f"เปลี่ยน “{tag}” เป็น (ถ้าตรงกับแท็กที่มีอยู่แล้ว จะถูกรวมเข้าด้วยกัน):",
                                       QLineEdit.EchoMode.Normal, tag)
        new = new.strip().replace(",", " ").replace(";", " ") if ok else ""
        if not new or new == tag:
            return
        ids = self.lib.rename_tag(tag, new)
        if self.scope == ("tag", tag):
            self.scope = ("tag", new)
        self.statusBar().showMessage(f"เปลี่ยนชื่อแท็กใน {len(ids):,} รูปแล้ว", 5000)
        self._after_tag_change(ids)

    def delete_tag_everywhere(self, tag):
        ids = self.lib.ids_with_tag(tag)
        if QMessageBox.question(self, "ลบแท็ก", f"ลบแท็ก “{tag}” ออกจากทั้ง {len(ids):,} รูป?") \
                != QMessageBox.StandardButton.Yes:
            return
        changed = self.lib.remove_tags(ids, [tag])
        self.statusBar().showMessage(f"ลบแท็ก “{tag}” จาก {len(changed):,} รูปแล้ว", 5000)
        self._after_tag_change(changed)

    # ================================================================== export / xmp / import
    def export_dialog(self):
        rows = self.model.rows
        sel = self.selected_ids() if self.mode == PAGE_GALLERY else self.target_ids()
        dlg = ExportDialog(self, len(sel), sum(1 for r in rows if r[4] > 0),
                           sum(1 for r in rows if r[3] >= 3), len(rows))
        if not dlg.exec():
            return
        scope, dest, edge, quality, xmp = dlg.values()
        if scope == "sel":
            chosen = set(sel)
            items = [r for r in rows if r[0] in chosen]
        elif scope == "pick":
            items = [r for r in rows if r[4] > 0]
        elif scope == "rated":
            items = [r for r in rows if r[3] >= 3]
        else:
            items = list(rows)
        items = [(r[0], r[1], r[2], r[3], r[4]) for r in items]
        if not items:
            self.statusBar().showMessage("ไม่มีไฟล์ตามที่เลือกส่งออก", 3000)
            return

        def fn(task):
            return tools.export_files(items, dest, edge, quality, xmp, task)

        def done(res):
            ok, errs = res
            self.statusBar().showMessage(f"ส่งออกแล้ว {ok:,} ไฟล์ → {dest}" + (f" · ล้มเหลว {len(errs)}" if errs else ""), 8000)

        self.run_task(fn, done, None, "กำลังส่งออก…")

    def write_xmp_selected(self):
        ids = set(self.target_ids())
        rows = [r for r in self.model.rows if r[0] in ids]

        def fn(task):
            for r in rows:
                media.write_xmp_rating(r[1], r[3], r[4])
            return len(rows)

        self.run_task(fn, lambda n: self.statusBar().showMessage(f"เขียน .xmp แล้ว {n} ไฟล์", 4000), None, "เขียน .xmp…")

    def import_old(self):
        start = os.environ.get("LOCALAPPDATA", "")
        f, _ = QFileDialog.getOpenFileName(self, "เลือกฐานข้อมูล Photos Viewer 4/5 (photos.sqlite3)", start,
                                           "SQLite (*.sqlite3 *.db *.sqlite)")
        if not f:
            return

        def done(res):
            self.refresh_sidebar()
            self.reload()
            QMessageBox.information(self, "นำเข้าเสร็จ",
                                    f"แท็ก {res['tags']:,} รูป · รายการโปรด→Pick {res['favorites']:,} รูป · อัลบั้ม {res['albums']}\n"
                                    "(นำเข้าเฉพาะรูปที่อยู่ในคลังนี้แล้ว – เพิ่มโฟลเดอร์ก่อนถ้าจำนวนน้อยกว่าที่คาด)")

        self.run_task(lambda t: self.lib.import_v5(f), done, None, "นำเข้า…")

    def clear_thumb_cache(self):
        import shutil
        shutil.rmtree(os.path.join(self.data_dir, "thumbs"), ignore_errors=True)
        self.thumbs.pix.clear()
        self.thumbs.clear_failed()
        self.reload()
        self.statusBar().showMessage("ล้างแคชภาพย่อแล้ว", 3000)

    # ================================================================== collections: duplicates / similar / people
    def show_collection(self, kind, ids, group, title):
        self.collection = {"kind": kind, "ids": ids, "group": group, "title": title}
        self.reload(keep=False)

    def close_collection(self, reload=True):
        self.collection = None
        if reload:
            self.reload(keep=False)

    def find_duplicates(self):
        ids = [r[0] for r in self.model.rows if r[2] == 0]
        if len(ids) < 2:
            return
        thr, ok = QInputDialog.getInt(self, "หารูปซ้ำ/คล้ายกัน",
                                      f"ความต่างสูงสุด (บิต, 0 = เหมือนเป๊ะ, 6 = แนะนำ, 12 = หลวม)\nตรวจ {len(ids):,} รูป:",
                                      6, 0, 16)
        if not ok:
            return

        def fn(task):
            todo = self.lib.pending_hash(ids)
            def h(r):
                try:
                    _, _, im = media.load_for_view(r["disp"], 96)
                    return (media.dhash_of(im), r["id"])
                except Exception:
                    return None
            with ThreadPoolExecutor(4) as ex:
                out = []
                for n, v in enumerate(ex.map(h, todo)):
                    if v:
                        out.append(v)
                    if n % 50 == 0:
                        task.progress.emit((n, len(todo)))
                self.lib.save_hashes(out)
            return tools.cluster_hashes(self.lib.hashes_for(ids), thr, task.is_cancelled)

        def done(groups):
            if not groups:
                self.statusBar().showMessage("ไม่พบรูปซ้ำ/คล้ายกัน", 5000)
                return
            flat, gmap = [], {}
            for gi, g in enumerate(groups):
                for i in g:
                    flat.append(i)
                    gmap[i] = gi
            self.dup_groups = groups
            self.show_collection("dup", flat, gmap, f"พบ {len(groups)} กลุ่มที่ซ้ำ/คล้ายกัน ({len(flat)} รูป) – เลขมุมขวาบนคือกลุ่ม")

        self.run_task(fn, done, None, "คำนวณลายนิ้วมือรูป…")

    def select_all_but_best(self):
        groups = getattr(self, "dup_groups", None)
        if not groups:
            return

        def fn(task):
            drop = []
            for n, g in enumerate(groups):
                infos = self.lib.infos_for(g)
                members = [infos[i] for i in g if i in infos]
                if len(members) > 1:
                    best = tools.best_of(members)
                    drop += [m["id"] for k, m in enumerate(members) if k != best]
                task.progress.emit((n + 1, len(groups)))
            return drop

        def done(drop):
            from PyQt6.QtCore import QItemSelectionModel
            self.view.clearSelection()
            for i in drop:
                r = self.model.row_of(i)
                if r >= 0:
                    self.view.selectionModel().select(self.model.index(r), QItemSelectionModel.SelectionFlag.Select)
            self.statusBar().showMessage(f"เลือก {len(drop)} รูปที่ควรลบ (ตัวดีที่สุดของแต่ละกลุ่มไม่ถูกเลือก) – ตรวจแล้วกด ลบที่เลือก", 8000)

        self.run_task(fn, done, None, "จัดอันดับรูปในแต่ละกลุ่ม…")

    def find_similar(self):
        ids = self.target_ids()
        if not ids:
            return
        tid = ids[0]

        def fn(task):
            info = self.lib.info(tid)
            if info["kind"] != 0:
                return None
            if info["dhash"] is None:
                _, _, im = media.load_for_view(info["disp"], 96)
                self.lib.save_hashes([(media.dhash_of(im), tid)])
                info = self.lib.info(tid)
            return tools.similar_to(info["dhash"], self.lib.hashes_for(None), 14)

        def done(res):
            if not res:
                self.statusBar().showMessage("ใช้ได้กับรูปภาพเท่านั้น หรือไม่พบรูปคล้าย", 4000)
                return
            self.show_collection("similar", res, {}, f"รูปที่คล้ายกับรูปที่เลือก {len(res)} รูป (เรียงจากคล้ายที่สุด)")

        self.run_task(fn, done, None, "ค้นหารูปคล้าย…")

    # ---- faces (optional dependency)
    def refresh_people(self):
        self.list_people.clear()
        try:
            from . import faces
            for pid, name, n in faces.people_list(self.lib):
                it = QListWidgetItem(f"{name or f'คนที่ {pid}'}  ({n})")
                it.setData(UR, pid)
                self.list_people.addItem(it)
        except Exception:
            pass

    def scan_faces(self):
        from . import faces
        ok, msg = faces.available()
        if not ok:
            QMessageBox.warning(self, "Face Recognition", msg)
            return
        ids = [r[0] for r in self.model.rows if r[2] == 0] or None

        def fn(task):
            return faces.scan(self.lib, ids, task)

        def done(res):
            self.refresh_people()
            self.tabs.setCurrentWidget(self.list_people)
            QMessageBox.information(self, "สแกนใบหน้าเสร็จ", f"สแกน {res['scanned']:,} รูป · พบใบหน้า {res['faces']:,} · คน {res['people']:,}")

        self.run_task(fn, done, None, "สแกนใบหน้า…")

    def _people_menu(self, pos):
        item = self.list_people.itemAt(pos)
        if not item:
            return
        from . import faces
        pid = item.data(UR)
        m = QMenu(self)

        def rename():
            name, ok = QInputDialog.getText(self, "ตั้งชื่อ", "ชื่อ:")
            if ok:
                faces.rename(self.lib, pid, name.strip())
                self.refresh_people()
                if name.strip():
                    n_img = len(faces.images_of(self.lib, pid))
                    ask = QMessageBox.question(self, "ติดแท็กชื่อ",
                                               f"ติดแท็ก “{name.strip()}” ให้ {n_img:,} รูปที่มีคนนี้เลยไหม?")
                    if ask == QMessageBox.StandardButton.Yes:
                        tag_this()

        def tag_this():
            name = next((n for p_, n, _c in faces.people_list(self.lib) if p_ == pid), "")
            if name.strip():
                ids = faces.images_of(self.lib, pid)
                self.lib.add_tags(ids, [name.strip()])
                self.statusBar().showMessage(f"ติดแท็ก “{name.strip()}” ให้ {len(ids):,} รูปแล้ว", 5000)
                self._after_tag_change(ids)

        def merge():
            others = [(i, it.text()) for i, it in ((j, self.list_people.item(j)) for j in range(self.list_people.count()))
                      if it.data(UR) != pid]
            if not others:
                return
            label, ok = QInputDialog.getItem(self, "รวมกับ…", "รวมคนนี้เข้ากับ:", [t for _, t in others], 0, False)
            if ok:
                tgt = self.list_people.item(next(i for i, t in others if t == label)).data(UR)
                faces.merge(self.lib, pid, tgt)
                self.refresh_people()

        m.addAction("ตั้งชื่อ…", rename)
        m.addAction("ติดแท็กชื่อนี้ให้ทุกรูปที่มีคนนี้", tag_this)
        m.addAction("รวมกับคนอื่น…", merge)
        m.exec(self.list_people.viewport().mapToGlobal(pos))
