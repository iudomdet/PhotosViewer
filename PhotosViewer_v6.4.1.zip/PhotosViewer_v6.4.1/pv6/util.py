"""Small cross-cutting helpers: paths, tags, trash, Explorer integration."""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

PHOTO_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tif", ".tiff", ".heic", ".heif"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".wmv", ".mts", ".m2ts", ".3gp", ".webm"}
SKIP_DIRS = {"$recycle.bin", "system volume information", "@eadir", ".thumbnails", "lost+found"}

try:
    from send2trash import send2trash as _send2trash
except Exception:  # pragma: no cover
    _send2trash = None


def app_data_dir() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.join(Path.home(), ".local", "share")
    path = os.path.join(base, "PhotosViewer6")
    os.makedirs(path, exist_ok=True)
    return path


def canon(path: str) -> str:
    """Index key for a path: absolute and case-folded on Windows."""
    return os.path.normcase(os.path.abspath(path))


def scope_range(folder: str) -> tuple[str, str]:
    """[prefix, upper) key range matching everything below *folder* (index-friendly)."""
    prefix = canon(folder).rstrip("\\/") + os.sep
    return prefix, prefix[:-1] + chr(ord(prefix[-1]) + 1)


def kind_of(name: str) -> int | None:
    ext = os.path.splitext(name)[1].lower()
    if ext in PHOTO_EXT:
        return 0
    if ext in VIDEO_EXT:
        return 1
    return None


def split_tags(value) -> list[str]:
    parts = re.split(r"[,;\r\n]+", value) if isinstance(value, str) else (value or [])
    seen, out = set(), []
    for item in parts:
        tag = str(item).strip()
        if tag and tag.casefold() not in seen:
            seen.add(tag.casefold())
            out.append(tag)
    return out


def human_size(value: float) -> str:
    value = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:,.0f} {unit}" if unit == "B" else f"{value:,.1f} {unit}"
        value /= 1024
    return ""


def recycle(paths) -> tuple[list[str], list[tuple[str, str]], bool]:
    """Move files to the Recycle Bin. Returns (done, failed, permanent)."""
    done, failed = [], []
    for path in paths:
        try:
            if _send2trash is not None:
                _send2trash(os.path.abspath(path))
            else:
                os.remove(path)
            done.append(path)
        except Exception as exc:
            failed.append((path, str(exc)))
    return done, failed, _send2trash is None


def trash_available() -> bool:
    return _send2trash is not None


def reveal_in_explorer(path: str):
    path = os.path.abspath(path)
    if sys.platform.startswith("win"):
        subprocess.Popen(["explorer", "/select," + path])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path])
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(path)])


def open_default(path: str):
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def no_window_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)
