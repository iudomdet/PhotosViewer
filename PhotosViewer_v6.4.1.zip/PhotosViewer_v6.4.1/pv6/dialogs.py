from __future__ import annotations

from PyQt6.QtCore import QStringListModel, Qt
from PyQt6.QtWidgets import QCompleter
from PyQt6.QtWidgets import (QListWidget, QListWidgetItem, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QSpinBox, QTextBrowser, QVBoxLayout)

SHORTCUTS = """
<h3>คัดรูป</h3>
<table cellpadding=3>
<tr><td><b>1 – 5</b></td><td>ให้ดาว</td><td><b>0</b></td><td>ล้างดาว</td></tr>
<tr><td><b>P</b></td><td>Pick (เก็บ)</td><td><b>X</b></td><td>Reject (ไม่เอา)</td></tr>
<tr><td><b>U</b></td><td>ล้างธง</td><td><b>Ctrl+Z / Ctrl+Y</b></td><td>ย้อนกลับ / ทำซ้ำ</td></tr>
<tr><td><b>Delete</b></td><td>ลบที่เลือก (ถังขยะ)</td><td><b>Ctrl+Shift+Del</b></td><td>ลบทุกรูปที่ Reject</td></tr>
</table>
<h3>ดูรูป</h3>
<table cellpadding=3>
<tr><td><b>Enter / ดับเบิลคลิก</b></td><td>เปิดดูเต็มจอ</td><td><b>Esc</b></td><td>กลับ</td></tr>
<tr><td><b>← → / Space / Backspace</b></td><td>รูปถัดไป / ก่อนหน้า</td><td><b>Z</b></td><td>ซูม 100% (เช็คโฟกัส)</td></tr>
<tr><td><b>ดับเบิลคลิก</b></td><td>กลับแกลเลอรี</td><td><b>ล้อเมาส์</b></td><td>ซูมเข้า/ออก</td></tr>
<tr><td><b>F</b></td><td>พอดีจอ</td><td><b>+ / −</b></td><td>ซูม</td></tr>
<tr><td><b>I</b></td><td>ซ่อน/แสดงข้อมูล</td><td><b>S</b></td><td>สไลด์โชว์</td></tr>
<tr><td><b>C</b></td><td>เทียบรูป (เลือก 2–4 รูปก่อน)</td><td><b>L</b></td><td>ล็อกซูมให้ตรงกัน (โหมดเทียบ)</td></tr>
<tr><td><b>F11</b></td><td>เต็มหน้าจอ</td><td><b>E</b></td><td>แสดงใน Explorer</td></tr>
</table>
"""


class ShortcutsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ปุ่มลัด")
        self.resize(640, 420)
        lay = QVBoxLayout(self)
        tb = QTextBrowser()
        tb.setHtml(SHORTCUTS)
        lay.addWidget(tb)


class ExportDialog(QDialog):
    def __init__(self, parent, n_sel: int, n_pick: int, n_rated: int, n_all: int):
        super().__init__(parent)
        self.setWindowTitle("ส่งออก")
        self.resize(460, 260)
        form = QFormLayout(self)
        self.scope = QComboBox()
        self.scope.addItem(f"ที่เลือก ({n_sel})", "sel")
        self.scope.addItem(f"ที่ Pick ในมุมมองนี้ ({n_pick})", "pick")
        self.scope.addItem(f"ที่ให้ดาว ≥ 3 ในมุมมองนี้ ({n_rated})", "rated")
        self.scope.addItem(f"ทั้งหมดในมุมมองนี้ ({n_all})", "all")
        self.scope.setCurrentIndex(0 if n_sel > 1 else 1)
        form.addRow("ส่งออก:", self.scope)
        self.dest = QLineEdit()
        b = QPushButton("เลือก…")
        b.clicked.connect(self._pick)
        row = QHBoxLayout()
        row.addWidget(self.dest, 1)
        row.addWidget(b)
        form.addRow("ปลายทาง:", row)
        self.edge = QComboBox()
        for label, v in (("ขนาดเดิม", 0), ("4096 px", 4096), ("3000 px", 3000), ("2048 px", 2048),
                         ("1600 px", 1600), ("1080 px", 1080)):
            self.edge.addItem(label, v)
        form.addRow("ด้านยาว:", self.edge)
        self.quality = QSpinBox()
        self.quality.setRange(40, 100)
        self.quality.setValue(90)
        form.addRow("คุณภาพ JPEG:", self.quality)
        self.xmp = QCheckBox("เขียนไฟล์ .xmp (ดาว/ธง) ข้างไฟล์ที่ส่งออก")
        form.addRow("", self.xmp)
        form.addRow("", QLabel("รูป → บันทึกเป็น JPEG (ไม่เขียนทับไฟล์เดิม) · วิดีโอ → คัดลอกไฟล์เดิม"))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def _pick(self):
        d = QFileDialog.getExistingDirectory(self, "เลือกโฟลเดอร์ปลายทาง", self.dest.text())
        if d:
            self.dest.setText(d)

    def _ok(self):
        if self.dest.text().strip():
            self.accept()

    def values(self):
        return (self.scope.currentData(), self.dest.text().strip(), self.edge.currentData(),
                self.quality.value(), self.xmp.isChecked())


class TagRemoveDialog(QDialog):
    """Tick the tags to remove from the selected images. tags: [(name, count)]."""

    def __init__(self, parent, tags, total: int):
        super().__init__(parent)
        self.setWindowTitle("ลบแท็ก")
        self.resize(380, 460)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"ติ๊กแท็กที่ต้องการลบออกจาก {total:,} รูปที่เลือก\n(ตัวเลข = จำนวนรูปที่มีแท็กนี้)"))
        self.filter = QLineEdit()
        self.filter.setPlaceholderText("พิมพ์เพื่อกรองรายการ…")
        self.filter.textChanged.connect(self._filter)
        lay.addWidget(self.filter)
        self.list = QListWidget()
        for name, n in tags:
            it = QListWidgetItem(f"{name}   ({n}/{total})")
            it.setData(Qt.ItemDataRole.UserRole, name)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked)
            self.list.addItem(it)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        b_all = QPushButton("ติ๊กทั้งหมดที่เห็น")
        b_none = QPushButton("ล้างที่ติ๊ก")
        b_all.clicked.connect(lambda: self._set_all(Qt.CheckState.Checked))
        b_none.clicked.connect(lambda: self._set_all(Qt.CheckState.Unchecked))
        row.addWidget(b_all)
        row.addWidget(b_none)
        lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _filter(self, text):
        t = text.strip().casefold()
        for i in range(self.list.count()):
            it = self.list.item(i)
            it.setHidden(bool(t) and t not in it.data(Qt.ItemDataRole.UserRole).casefold())

    def _set_all(self, state):
        for i in range(self.list.count()):
            it = self.list.item(i)
            if not it.isHidden():
                it.setCheckState(state)

    def chosen(self):
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.CheckState.Checked]


class TagLineEdit(QLineEdit):
    """Comma-separated tag entry with auto-complete for the tag being typed."""

    def __init__(self, known, parent=None):
        super().__init__(parent)
        self.known = known
        self.model_ = QStringListModel(known, self)
        self.comp = QCompleter(self.model_, self)
        self.comp.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.comp.setFilterMode(Qt.MatchFlag.MatchContains)
        self.comp.setWidget(self)
        self.comp.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.comp.activated[str].connect(self._insert)
        self.textEdited.connect(self._typed)

    def _token_bounds(self):
        text, pos = self.text(), self.cursorPosition()
        start = max(text.rfind(",", 0, pos), text.rfind(";", 0, pos)) + 1
        return start, pos

    def _typed(self, _):
        a, b = self._token_bounds()
        token = self.text()[a:b].strip()
        if not token:
            self.comp.popup().hide()
            return
        have = {t.strip().casefold() for t in self.text().replace(";", ",").split(",")}
        self.model_.setStringList([k for k in self.known if k.casefold() not in have or k.casefold() == token.casefold()])
        self.comp.setCompletionPrefix(token)
        if self.comp.completionCount():
            self.comp.complete()
        else:
            self.comp.popup().hide()

    def _insert(self, chosen):
        a, b = self._token_bounds()
        text = self.text()
        head = text[:a].rstrip()
        new = head + (" " if head else "") + chosen + ", " + text[b:].lstrip()
        self.setText(new)
        self.setCursorPosition(len(head) + (1 if head else 0) + len(chosen) + 2)

    def add_tag(self, tag):
        cur = [t for t in self.text().replace(";", ",").split(",") if t.strip()]
        if tag.casefold() not in {t.strip().casefold() for t in cur}:
            cur.append(tag)
        self.setText(", ".join(t.strip() for t in cur) + ", ")
        self.setFocus()


class TagEditDialog(QDialog):
    """Type tags (auto-complete from existing ones) or click the frequently used ones to add them."""

    def __init__(self, parent, all_tags, text, title, label):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(560, 220)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(label))
        self.edit = TagLineEdit([n for n, _ in all_tags])
        self.edit.setText(text + (", " if text.strip() else ""))
        lay.addWidget(self.edit)
        if all_tags:
            lay.addWidget(QLabel("แท็กที่ใช้บ่อย (คลิกเพื่อเพิ่ม):"))
            row = QHBoxLayout()
            for n, c in all_tags[:10]:
                b = QPushButton(f"{n} ({c})")
                b.clicked.connect(lambda _=False, n=n: self.edit.add_tag(n))
                row.addWidget(b)
            row.addStretch(1)
            lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.edit.setFocus()

    def tags(self):
        from .util import split_tags
        return split_tags(self.edit.text())
