import sys
from pv6.entry import main
sys.exit(main())
