@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
set "PY="
for %%V in (3.12 3.11 3.10 3.13) do (
  if not defined PY (
    py -%%V-64 -c "import sys" >nul 2>nul && set "PY=py -%%V-64"
  )
)
if not defined PY ( echo ไม่พบ Python 3.10-3.13 ^(64-bit^) & pause & exit /b 1 )
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt pyinstaller "setuptools<81" || goto :fail
%PY% -m pip install -r requirements-face.txt || goto :fail
%PY% -m pip install face-recognition --no-deps || goto :fail
%PY% -m PyInstaller --noconfirm --clean --windowed --name PhotosViewer6_Face ^
  --collect-all imageio_ffmpeg --collect-all pillow_heif --collect-submodules send2trash ^
  --collect-all face_recognition_models --hidden-import face_recognition ^
  --hidden-import win32com.propsys.propsys --hidden-import win32com.shell.shell ^
  --exclude-module PyQt6.QtWebEngineCore --exclude-module PyQt6.QtQml ^
  photos_viewer.py || goto :fail
echo สำเร็จ: dist\PhotosViewer6_Face\PhotosViewer6_Face.exe
pause & exit /b 0
:fail
echo BUILD FAILED & pause & exit /b 1
