@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
call :findpy
if not defined PY ( echo ไม่พบ Python 3.10-3.13 & pause & exit /b 1 )
%PY% -m pip install -r requirements.txt
%PY% photos_viewer.py
exit /b
:findpy
for %%V in (3.12 3.11 3.10 3.13) do (
  if not defined PY (
    py -%%V-64 -c "import sys" >nul 2>nul && set "PY=py -%%V-64"
  )
)
exit /b
