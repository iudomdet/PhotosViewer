@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
set "PY="
for %%V in (3.12 3.11 3.10 3.13) do (
  if not defined PY (
    py -%%V-64 -c "import sys" >nul 2>nul && set "PY=py -%%V-64"
  )
)
if not defined PY ( echo ไม่พบ Python 3.10-3.13 ^(64-bit^) & pause & exit /b 1 )
echo ใช้ Python: %PY%
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt pyinstaller "setuptools<81" || goto :fail
%PY% -m PyInstaller --noconfirm --clean --windowed --name PhotosViewer6 ^
  --collect-all imageio_ffmpeg --collect-all pillow_heif --collect-submodules send2trash ^
  --hidden-import win32com.propsys.propsys --hidden-import win32com.shell.shell ^
  --exclude-module PyQt6.QtWebEngineCore --exclude-module PyQt6.QtQml --exclude-module PyQt6.Qt3DCore ^
  photos_viewer.py || goto :fail
echo.
echo สำเร็จ: dist\PhotosViewer6\PhotosViewer6.exe  ^(คัดลอกทั้งโฟลเดอร์ PhotosViewer6 ไปใช้เครื่องอื่นได้^)
pause & exit /b 0
:fail
echo BUILD FAILED & pause & exit /b 1
